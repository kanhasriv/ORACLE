from flask import Flask
from config import config,db
from flask import request, jsonify
import jsonify
import json
import pandas as pd 
import boto3
import pyodbc
import psycopg2
import redshift
import snowflake
import teradata
from datetime import datetime , date
import uuid
app=Flask(__name__)
idea_date_format="%Y/%m/%d %H:%M:%S"

column_data_type = ['INTEGER','BYTEINT','BIGINT','SMALLINT']
role="arn:aws:iam::185484414899:role/POC_STEP"
def extract_query(table_name, schema_name, source_link_service_id,  job_run_id, project_id,
                  split, column_name, split_from, split_to,load_type,split_id,discover_id):
    """
    Get the name of all columns  in given table
    :param table_name,schema_name,source_link_service_id,job_run_id,param column_name,load_type,
     check_max_value,project_id
    :return: TD_Query
    """
    try:
        query={"discover_id":discover_id,"database_nm":schema_name,"table_nm":table_name}
        result=db.discover_column.find(query,{"_id":0,"column_nm":1})
        result=list(result)
        param = []
        #data = list(result)
        result=['CONTACT_ID','CUSTOMER_ID','EMAIL','FIRST_NAME','LAST_NAME','PHONE']
        data=[]
        print("hh",schema_name)
        for i in result:
            data.append({"column_nm":i})
        print(data)
        if len(data) > 1:
            
            for item in data:
                item = item['column_nm']
                param.append(item)
            # Check for Split
            if split or load_type.upper() == "ADHOC":
                query = f"SELECT {param} FROM {schema_name}.{table_name} where {column_name} >= #{split_from}# and {column_name} <= #{split_to}#"
            elif load_type.upper() == "INCREMENTAL LOAD" and not split and split_from != "0":
                query = f"SELECT {param} FROM {schema_name}.{table_name} where {column_name} >= #{split_from}#"
            else:
                query = f"SELECT {param} FROM {schema_name}.{table_name}"
                print("qthjj",query)

            query = query.replace("'", "\"")
            query = query.replace("[", "")
            query = query.replace("]", "")
        else:
            return False


    except Exception:
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_s3": "Fail",
                                  "splits.$[stat].split_status_rs": "Fail",
                                  "splits.$[stat].end_time_s3": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_s3": None,
                                  "splits.$[stat].message": "Teradata DWH to s3 migration failed"}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            fail_dict={}
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            fail_dict.update({"message": "Discovery not performed. Please perform discovery"})
            db.job_run_detail.update_one(updatequery, {"$set": fail_dict})
        return False


    return query

@app.route("/idea/services/migration/data/step-run",methods=["POST"])
def step_function():
    print("Hello Starts in Step FUnction")
    data=request.get_json()
    job_id=data["job_id"]
    project_id=data["project_id"]
    query={"job_id":job_id,"project_id":project_id,"active":True}
    result=db.job_registry.find(query,{"_id":0})
    result=list(result)
    
    if not result:
        resp={
            "error":"Error in Result"
        }
        return resp
    job_name=result[0]["job_name"]
    data=result[0]["data"]
    source_link_service_id=result[0]["source_link_service_id"]
    source_link_service_details=db.link_service.find_one({"link_service_id":source_link_service_id,"active":True})
    print("source_link_service_details",source_link_service_details)
    if source_link_service_details is None:
        resp={
            "error":"Invalid Link Service ID"
        }
        return resp
    sink_link_service_id=result[0]["sink_link_service_id"]
    sink_link_service_details=db.link_service.find_one({"link_service_id":sink_link_service_id,"active":True})

    if sink_link_service_details is None:
        resp={
            "error":"Invalid Link Service ID"
        }
    
    discover_id="51d984ca-3927-45d1-ac05-2b2b11afd1a2"
    link_service_type="Oracle DWH"    
    if link_service_type=="Oracle DWH":
        hostname="4.227.133.160"
        port=1521
        sid="cdb2"
        username="C#DEMO_USER"
        password="pass123"
        database="demo_data"
        connection_string="DRIVER=Oracle in instantclient_21_9; DBQ={host}:{port}/{sid};UID={username};PWD={password}".format(host=hostname,port=port,username=username,password=password,sid=database)
        print(connection_string)
        try:
            conn=pyodbc.connect(connection_string)
            print("Td COnnected")
        except pyodbc.error as exception:
            resp={
                "error":"Test Connection failed"
            }
            return resp
    
    load_type=result[0]["load_type"]
    query={"job_id":job_id,"active":True}
    job_run_result=db.job_run.find(query,{"_id":0}).sort("start_time",-1).limit(1)
    job_run_result=list(job_run_result)
    if len(job_run_result)==1:
        if job_run_result[0]["status"]=="InProgress":
            resp={
                "error":"Job is already in Progress"
            }
            return resp
        elif job_run_result[0]["re_run_flag"]==True:
            job_run_id_prev=job_run_result[0]["job_run_id"]
            query={"job_run_id":job_run_id_prev,"project_id":project_id}
            newvalues={"$set":{"re_run_flag":False}}
            db.job_run.update_one(query,newvalues)

    start_time=int(datetime.utcnow().timestamp())
    start_time_str=datetime.fromtimestamp(start_time).strftime(idea_date_format)
    job_run_id=str(uuid.uuid4())

    end_time=""
    end_time_str=""
    status="InProgress"
    insert_val={
        "job_id":job_id,
        "job_run_id":job_run_id,
        "project_id":project_id,
        "job_type":"Data_Migration",
        "status":status,
        "job_start_at":start_time,
        "job_end_at":end_time,
        "job_end_at_str":end_time_str,
        "load_type":load_type,
        "run_type":"job_run",
        "re_run_flag":False
    }

    db.job_run.insert(insert_val)

    for item in data["database_details"]:
        table_list=item["tables"]
        schema_name=item["database"]
        for table_name in table_list:
            query={"job_id":job_id,"object_name":table_name}
            job_run_detail=db.job_detail.find_one(query,{"_id":0})
            job_run_detail["job_run_id"]=job_run_id
            job_run_detail["start_time"]=start_time
            job_run_detail["start_time_str"]=start_time_str
            job_run_detail["status_s3"]="Not Started"
            job_run_detail["status_rs"]="Not Started"
            if source_link_service_details["link_service_type"].upper() == "TERADATA DWH":
                table_metadata=db.table_migration_dashboard.find_one({
                    "database_nm":schema_name,"table_nm":table_name,"active":True,"discover_id":discover_id
                })
                print(table_metadata)
                job_run_detail["split"]=table_metadata["split"]
            else:
                job_run_detail["split"]=False

    split=job_run_detail["split"]
    split_id=None
    split_from=None
    split_to=None
    column_name=None
    glue_td_job_name="Oracle_S3"

    query={"link_service_id":sink_link_service_id,"active":True}
    result=db.link_service.find_one(query,{"_id":0})
    tgt_hostname="pihjdmo-capgemini_apac_poc.snowflakecomputing.com"
    tgt_user_name="IDEA_MIGRATION_APPL_ADM_USER"
    tgt_password="idea_Snowflake23"
    tgt_db_name="D_IDEA_MIGRATION_DB"
    tgt_vendor="snowflake"
    warehouse="W_IDEA_MIGRATION_DATA_M"
    schema_name="IDEA_SCHEMA"

    sink_db_conn_string=config[tgt_vendor]["conn"].format(user=tgt_user_name,
                                                          password=tgt_password,
                                                          host=tgt_hostname,
                                                          warehouse=warehouse
                                                        )
    print(sink_db_conn_string)
    conn = pyodbc.connect(sf_conn_string)
    cur = conn.cursor()
    database_name=
    pre_copy_script=snowflake.query["check_schema_query"].format(schema_name=schema_name.lower(),table_name=table_name.lower())
    schema_df=pd.read_sql_query(pre_copy_script,redshift_conn)
    glue_job_rs_name="S3_Snowflake"

    if len(table_list)==1:
        if split==False:
            print("No Split")

            if load_type.upper() == "FULL LOAD":
                pre_copy_script=snowflake.query["pre_copy_script"].format(schema_name=schema_name.lower(),table_name=table_name.lower())
                rs_cursor=redshift_conn.cursor()

                rs_cursor.execute(pre_copy_script)
            elif load_type.upper()=="INCREMENTAL LOAD":
                column_name="DISP_ID"

                if "bookmark" in table_metadata:
                    min_value = table_metadata["bookmark"]
                    print("Min Value",min_value)
                    # To convert the string value stored in document DB into
                    # respective DATE and TIMESTAMP
                    if table_metadata['column_data_type'].upper() == "DATE":
                        min_value = date(*map(int, min_value.split('-'))) + relativedelta(days=1)
                    elif table_metadata['column_data_type'].upper() == "TIMESTAMP":
                        min_value = pd.to_datetime(min_value) + pd.DateOffset(days=1)
                    elif table_metadata['column_data_type'].upper() in column_data_type:
                        min_value = int(min_value) + 1
                    else:
                        min_value = 0
                    tera_query = teradata.data_migration["max_query"].format(
                                    column_name=table_metadata["column_nm"],
                                    schema_name=schema_name,
                                    table_name=table_name)
                    max_value = pd.read_sql_query(tera_query, conn).iloc[0]["max_value"]
                    db.job_run_detail.update_one(
                                    {"job_run_id": job_run_id, "object_name": table_name,
                                    "object_parent": schema_name},
                                    {"$set": {"max_value": str(max_value),
                                            "column_name": table_metadata["column_nm"],
                                            "min_value": str(min_value)}})
                split_from=int(min_value)
            print(schema_name)
            query=extract_query(table_name,schema_name,source_link_service_id,job_run_id,project_id,split,column_name,split_from,split_to,load_type,split_id,discover_id)
            print(query)
            base_timestamp=datetime.utcnow().strftime("%Y%m%d%H%M%S")
            machine_client=boto3.client(
                service_name="stepfunctions",
                region_name="us-west-2",
                aws_access_key_id="AKIASWL53R6Z2P2QMCOV",
                aws_secret_access_key="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"
            )

            cmd1 = "COPY INTO {database_name}.{schema}.{table} FROM (select ".format(
                schema=schema_name.upper(), table=table_name.upper(),database_name=tgt_db_name)
            schema_columns =['CONTACT_ID','CUSTOMER_ID','EMAIL','FIRST_NAME','LAST_NAME','PHONE']

            cmd1+="$1:CONTACT_ID::INTEGER, $1:CUSTOMER_ID::INTEGER, $1:EMAIL::CHAR (100), $1:FIRST_NAME::CHAR (100),$1:LAST_NAME::CHAR (100),$1:PHONE::CHAR (100)"
            
            path = " from @{stage}/{schema_name}/{table_name}/load_date={file_date}/load_time=" \
                   "{base_timestamp}) FORCE = TRUE".format(
                stage="IDEA_SNOWFLAKE_STG",
                schema_name=schema_name,
                table_name=table_name,
                file_date=base_timestamp[:8],
                base_timestamp=base_timestamp[8:])
            copy_cmd = cmd1 + path
            input_object={
                "td_input":{
                    "job_name_td":glue_td_job_name,
                    "oracle_hostname":hostname,
                    "oracle_port":"1521",
                    "oracle_driver_name":"oracle.jdbc.OracleDriver",
                    "sid":sid,
                    "source_link_service_id":source_link_service_id,
                    "db_name":schema_name,
                    "table_name":table_name,
                    "bucket_name":"my-bucket-kanha",
                    "date":base_timestamp[:8],
                    "time":base_timestamp[8:],
                    "query":query
                },
                "snowflake_input":{
                    "job_name_snowflake":glue_job_rs_name,
                    "warehouse":warehouse,
                    "table":table_name,
                    "schema":"IDEA_SCHEMA",
                    "load_type":"FULL LOAD",
                    "copy_cmd":copy_cmd,
                    "link_service_id":sink_link_service_id,
                    "idea_db": tgt_db_name,
                    "account": hostname.split(".snowflake")[0]    
                }
            }

            state_machine_Definition={
                "Comment":"A description of my state machine",
                "StartAt":"Oracle_FROM_S3",
                "States":{
                    "TD_FROM_S3":{
                        "Type":"Task",
                        "Resource":"arn:aws:states:::glue:startJobRun.sync",
                        "Parameters":{
                            "JobName.$":"$.td_input.job_name_td",
                            "Arguments":{
                                "--db_name.$":"$.td_input.db_name",
                                "--tb_name.$":"$.td_input.table_name",
                                "--oracle_hostname.$":"$.td_input.oracle_hostname",
                                "--oracle_port.$":"$.td_input.oracle_port",
                                "--sid.$":"$.td_input.sid",
                                "--link_service_id.$":"$.td_input.source_link_service_id",
                                "--bucket_name.$":"$.td_input.bucket_name",
                                "--oracle_driver_name.$":"$.td_input.oracle_driver_name",
                                "--date.$":"$.td_input.date",
                                "--time.$":"$.td_input.time",
                                "--query.$":"$.td_input.query"
                            }
                        },
                        "ResultPath":"$.db_name",
                        "Next":"S3_FROM_Snowflake"
                    },
                    "S3_FROM_Snowflake":{
                        "Type":"Task",
                        "Resource":"arn:aws:states:::glue:startJobRun.sync",
                        "Parameters":{
                            "JobName.$":"$.snowflake_input.job_name_snowflake",
                            "Arguments":{
                                "--idea_db.$":"$.snowflake_input.idea_db",
                                "--account.$":"$.snowflake_input.account",
                                "--link_service_id.$":"$.snowflake_input.link_service_id",
                                '--copy_cmd.$':"$.snowflake_input.copy_cmd",
                                "--load_type.$":"$.snowflake_input.load_type",
                                "--schema.$":"$.snowflake_input.schema",
                                "--table.$":"$.snowflake_input.table",
                                "--warehouse.$":"$.snowflake_input.warehouse"
                            }
                        },
                        "End":True
                    },
                }
            }

            state_machine_Definition_str=json.dumps(state_machine_Definition)

            response=machine_client.create_state_machine(
                name="step_function_21s",
                definition=state_machine_Definition_str,
                roleArn=role
            )
            response=machine_client.start_execution(
                stateMachineArn=response["stateMachineArn"],
                input=json.dumps(input_object)
            )
            print(response)
        else:
            if load_type.upper() == "FULL LOAD":
                pre_copy_script=redshift.query["pre_copy_script"].format(schema_name=schema_name.lower(),table_name=table_name.lower())
                rs_cursor=redshift_conn.cursor()
                rs_cursor.execute(pre_copy_script)
            input_object={}
            Branches=[]
            tera_query = teradata.data_migration["max_query"].format(
                        column_name=table_metadata["column_nm"],
                        schema_name=schema_name,
                        table_name=table_name)
            max_value = pd.read_sql_query(tera_query, conn).iloc[0]["max_value"]
            print(max_value)
            tera_query = teradata.data_migration["min_query"].format(
                        column_name=table_metadata["column_nm"],
                        schema_name=schema_name,
                        table_name=table_name)
            min_value = pd.read_sql_query(tera_query, conn).iloc[0]['min_value']
            print(min_value)         
            if table_metadata["split_type"].upper() == "RANGE":
                splits_required = int(table_metadata["value"][0]["value"])
                print(splits_required)
                split_range = int((int(max_value) - int(min_value)) / splits_required)
                for i in range(splits_required):
                    print("i",i)
                    split_id = str(uuid.uuid4())
                    split_from = int(min_value)
                    print(split_from)
                    split_to = int(int(min_value) + split_range)
                    print(split_to)
                    min_value = int(min_value) + split_range + 1
                    split_response = {
                        "split_id": split_id,
                        "split_from": str(split_from),
                        "split_to": str(split_to),
                        "column_name": table_metadata["column_nm"],
                        "split_status_s3": "Not Started",
                        "split_status_rs": "Not Started"
                    }

                    # Inserting the split related metadata into job_run_detail
                    query = {"job_run_id": job_run_id, "object_name": table_name,
                                "object_parent": schema_name}
                    params = {"$push": {"splits": split_response}}
                    db.job_run_detail.update_one(query, params)
                    column_name=split_response["column_name"]
                    query=extract_query(table_name,schema_name,source_link_service_id,job_run_id,project_id,split,column_name,split_from,split_to,load_type,split_id,discover_id)
                    base_timestamp=datetime.utcnow().strftime("%Y%m%d%H%M%S")
                    input_object.update({
                        f"td_input_{split_from}_to_{split_to}":{
                            "job_name_td":glue_td_job_name,
                            "td_hostname":hostname,
                            "source_link_service_id":source_link_service_id,
                            "td_driver_name":config["aws"]["td_driver_name"],
                            "db_name":schema_name,
                            "table_name":table_name,
                            "bucket_name":"my-bucket-kanha",
                            "date":base_timestamp[:8],
                            "time":base_timestamp[8:],
                            "query":query
                            },
                        f"rs_input_{split_from}_to_{split_to}":{
                            "job_name_rs":glue_job_rs_name,
                            "rs_dbname":tgt_db_name,
                            "db_name":schema_name,
                            "tb_name":table_name,
                            "rs_hostname":tgt_hostname,
                            "source_link_service_id":source_link_service_id,
                            "sink_link_service_id":sink_link_service_id,
                            "rs_port":tgt_port,
                            "temp_dir":f's3://my-bucket-kanha/redshift_tempdir/{schema_name}/{table_name}/load_date={base_timestamp[:8]}/load_time={base_timestamp[8:]}',
                            "bucket_name":"my-bucket-kanha",
                            "date":base_timestamp[:8],
                            "time":base_timestamp[8:],
                            "connection":"Redshift"
                        }
                    })
                    branch={
                    "StartAt": f"TD_FROM_S3_{split_from}_to_{split_to}",
                    "States": {
                        f"TD_FROM_S3_{split_from}_to_{split_to}": {
                            "Type": "Task",
                             "Resource":"arn:aws:states:::glue:startJobRun.sync",
                             "Parameters":{                                
                                "JobName.$":f"$.td_input_{split_from}_to_{split_to}.job_name_td",
                                "Arguments":{
                                "--db_name.$":f"$.td_input_{split_from}_to_{split_to}.db_name",
                                "--tb_name.$":f"$.td_input_{split_from}_to_{split_to}.table_name",
                                "--td_hostname.$":f"$.td_input_{split_from}_to_{split_to}.td_hostname",
                                "--link_service_id.$":f"$.td_input_{split_from}_to_{split_to}.source_link_service_id",
                                "--bucket_name.$":f"$.td_input_{split_from}_to_{split_to}.bucket_name",
                                "--td_driver_name.$":f"$.td_input_{split_from}_to_{split_to}.td_driver_name",
                                "--date.$":f"$.td_input_{split_from}_to_{split_to}.date",
                                "--time.$":f"$.td_input_{split_from}_to_{split_to}.time",
                                "--query.$":f"$.td_input_{split_from}_to_{split_to}.query"
                                }
                            },
                            "ResultPath":"$.db_name",
                            "Next":f"S3_FROM_RS_{split_from}_to_{split_to}"
                        },
                        f"S3_FROM_RS_{split_from}_to_{split_to}": {
                            "Type": "Task",
                            "Resource":"arn:aws:states:::glue:startJobRun.sync",
                            "Parameters":{
                            "JobName.$":f"$.rs_input_{split_from}_to_{split_to}.job_name_rs",
                            "Arguments":{
                                "--rs_dbname.$":f"$.rs_input_{split_from}_to_{split_to}.rs_dbname",
                                "--db_name.$":f"$.rs_input_{split_from}_to_{split_to}.db_name",
                                "--tb_name.$":f"$.rs_input_{split_from}_to_{split_to}.tb_name",
                                '--rs_port.$':f"$.rs_input_{split_from}_to_{split_to}.rs_port",
                                "--rs_hostname.$":f"$.rs_input_{split_from}_to_{split_to}.rs_hostname",
                                "--src.$":f"$.rs_input_{split_from}_to_{split_to}.source_link_service_id",
                                "--link_service_id.$":f"$.rs_input_{split_from}_to_{split_to}.sink_link_service_id",
                                "--bucket_name.$":f"$.rs_input_{split_from}_to_{split_to}.bucket_name",
                                "--date.$":f"$.rs_input_{split_from}_to_{split_to}.date",
                                "--time.$":f"$.rs_input_{split_from}_to_{split_to}.time",
                                "--temp_dir.$":f"$.rs_input_{split_from}_to_{split_to}.temp_dir",
                                '--connection_name.$':f'$.rs_input_{split_from}_to_{split_to}.connection'
                            }
                            },
                            "End": True
                        }
                     }
                    }
                
                    Branches.append(branch)
                print(Branches)
                machine_client=boto3.client(
                    service_name="stepfunctions",
                    region_name="us-west-2",
                    aws_access_key_id="AKIA4CNDWREYTCJ3J7LG",
                    aws_secret_access_key="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"
                )

                state_machine_Definition={
                    "Comment":"A description of my state machine",
                    "StartAt":"Parallel",
                    "States":{
                        "Parallel":{
                            "Type":"Parallel",
                            "Branches":Branches,
                            "End":True
                        }
                    }
                }
        
                state_machine_Definition_str=json.dumps(state_machine_Definition)

                response=machine_client.create_state_machine(
                    name="step_function_122s",
                    definition=state_machine_Definition_str,
                    roleArn=role
                )
                response=machine_client.start_execution(
                    stateMachineArn=response["stateMachineArn"],
                    input=json.dumps(input_object)
                )

                   
            else:
                print("In Else Block")

            


                   
            
    else:
        Branches=[]
        input_object={}
        for item in data["database_details"]:
            tables_list=item["tables"]
            schema_name=item["database"]
            for table_name in tables_list:
                query={"job_id":job_id,"object_name":table_name}
                job_run_detail = db.job_detail.find_one(query, {"_id": 0})
                job_run_detail["job_run_id"] = job_run_id
                job_run_detail["start_time"] = start_time
                job_run_detail["start_time_str"] = start_time_str
                if source_link_service_details['link_service_type'].upper() == "TERADATA DWH":
                    # Fetching table metadata related details from
                    # table_migration_dashboard collection
                    table_metadata = db.table_migration_dashboard.find_one(
                        {"database_nm": schema_name,
                         "table_nm": table_name, "active": True,"discover_id":discover_id})
                    job_run_detail["split"] = table_metadata["split"]
                else:
                    job_run_detail["split"] = False
                db.job_run_detail.insert(job_run_detail)
                if load_type.upper() == "FULL LOAD":
                    pre_copy_script=redshift.query["pre_copy_script"].format(schema_name=schema_name.lower(),table_name=table_name.lower())
                    rs_cursor=redshift_conn.cursor()
                    rs_cursor.execute(pre_copy_script)
                elif load_type.upper()=="INCREMENTAL LOAD":
                    column_name="DISP_ID"

                    if "bookmark" in table_metadata:
                        min_value = table_metadata["bookmark"]
                        print("Min Value",min_value)
                        # To convert the string value stored in document DB into
                        # respective DATE and TIMESTAMP
                        if table_metadata['column_data_type'].upper() == "DATE":
                            min_value = date(*map(int, min_value.split('-'))) + relativedelta(days=1)
                        elif table_metadata['column_data_type'].upper() == "TIMESTAMP":
                            min_value = pd.to_datetime(min_value) + pd.DateOffset(days=1)
                        elif table_metadata['column_data_type'].upper() in column_data_type:
                            min_value = int(min_value) + 1
                        else:
                            min_value = 0
                        tera_query = teradata.data_migration["max_query"].format(
                                        column_name=table_metadata["column_nm"],
                                        schema_name=schema_name,
                                        table_name=table_name)
                        max_value = pd.read_sql_query(tera_query, conn).iloc[0]["max_value"]
                        db.job_run_detail.update_one(
                                        {"job_run_id": job_run_id, "object_name": table_name,
                                        "object_parent": schema_name},
                                        {"$set": {"max_value": str(max_value),
                                                "column_name": table_metadata["column_nm"],
                                                "min_value": str(min_value)}})
                    split_from=int(min_value)
                            
                query=extract_query(table_name,schema_name,source_link_service_id,job_run_id,project_id,split,column_name,split_from,split_to,load_type,split_id,discover_id)
                base_timestamp=datetime.utcnow().strftime("%Y%m%d%H%M%S")
                input_object.update({
                    f"td_input_{table_name}":{
                        "job_name_td":glue_td_job_name,
                        "td_hostname":hostname,
                        "source_link_service_id":source_link_service_id,
                        "td_driver_name":config["aws"]["td_driver_name"],
                        "db_name":schema_name,
                        "table_name":table_name,
                        "bucket_name":"my-bucket-kanha",
                        "date":base_timestamp[:8],
                        "time":base_timestamp[8:],
                        "query":query
                        },
                    f"rs_input_{table_name}":{
                        "job_name_rs":glue_job_rs_name,
                        "rs_dbname":tgt_db_name,
                        "db_name":schema_name,
                        "tb_name":table_name,
                        "rs_hostname":tgt_hostname,
                        "source_link_service_id":source_link_service_id,
                        "sink_link_service_id":sink_link_service_id,
                        "rs_port":tgt_port,
                        "temp_dir":f's3://my-bucket-kanha/redshift_tempdir/{schema_name}/{table_name}/load_date={base_timestamp[:8]}/load_time={base_timestamp[8:]}',
                        "bucket_name":"my-bucket-kanha",
                        "date":base_timestamp[:8],
                        "time":base_timestamp[8:],
                        "connection":"Redshift"
                        }
                    })

                branch={
                    "StartAt": F"TD_FROM_S3_{table_name}",
                    "States": {
                        f"TD_FROM_S3_{table_name}": {
                            "Type": "Task",
                             "Resource":"arn:aws:states:::glue:startJobRun.sync",
                             "Parameters":{                                
                                "JobName.$":f"$.td_input_{table_name}.job_name_td",
                                "Arguments":{
                                "--db_name.$":f"$.td_input_{table_name}.db_name",
                                "--tb_name.$":f"$.td_input_{table_name}.table_name",
                                "--td_hostname.$":f"$.td_input_{table_name}.td_hostname",
                                "--link_service_id.$":f"$.td_input_{table_name}.source_link_service_id",
                                "--bucket_name.$":f"$.td_input_{table_name}.bucket_name",
                                "--td_driver_name.$":f"$.td_input_{table_name}.td_driver_name",
                                "--date.$":f"$.td_input_{table_name}.date",
                                "--time.$":f"$.td_input_{table_name}.time",
                                "--query.$":f"$.td_input_{table_name}.query"
                                }
                            },
                            "ResultPath":"$.db_name",
                            "Next":f"S3_FROM_RS_{table_name}"
                        },
                        f"S3_FROM_RS_{table_name}": {
                            "Type": "Task",
                            "Resource":"arn:aws:states:::glue:startJobRun.sync",
                            "Parameters":{
                            "JobName.$":f"$.rs_input_{table_name}.job_name_rs",
                            "Arguments":{
                                "--rs_dbname.$":f"$.rs_input_{table_name}.rs_dbname",
                                "--db_name.$":f"$.rs_input_{table_name}.db_name",
                                "--tb_name.$":f"$.rs_input_{table_name}.tb_name",
                                '--rs_port.$':f"$.rs_input_{table_name}.rs_port",
                                "--rs_hostname.$":f"$.rs_input_{table_name}.rs_hostname",
                                "--src.$":f"$.rs_input_{table_name}.source_link_service_id",
                                "--link_service_id.$":f"$.rs_input_{table_name}.sink_link_service_id",
                                "--bucket_name.$":f"$.rs_input_{table_name}.bucket_name",
                                "--date.$":f"$.rs_input_{table_name}.date",
                                "--time.$":f"$.rs_input_{table_name}.time",
                                "--temp_dir.$":f"$.rs_input_{table_name}.temp_dir",
                                '--connection_name.$':f'$.rs_input_{table_name}.connection'
                            }
                            },
                            "End": True
                        }
                     }
                    }
                Branches.append(branch)

                
        print(Branches)
        machine_client=boto3.client(
            service_name="stepfunctions",
            region_name="us-west-2",
            aws_access_key_id="AKIAWZLXI4WE54LA66PA",
            aws_secret_access_key="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"
        )

        

        state_machine_Definition={
            "Comment":"A description of my state machine",
            "StartAt":"Parallel",
            "States":{
                "Parallel":{
                    "Type":"Parallel",
                    "Branches":Branches,
                    "End":True
                }
            }
        }
        
        state_machine_Definition_str=json.dumps(state_machine_Definition)

        response=machine_client.create_state_machine(
            name="step_function_6s",
            definition=state_machine_Definition_str,
            roleArn="arn:aws:iam::466790966665:role/POC_STEP"
        )
        response=machine_client.start_execution(
            stateMachineArn=response["stateMachineArn"],
            input=json.dumps(input_object)
        )

    resp={
        "status":"Executed Successfully"
    }
    return resp

if __name__=="__main__":
    app.run(debug=True,port="5000")