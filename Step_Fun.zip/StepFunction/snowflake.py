query = {
    "check_schema_query": "select * from {schema_name}.{schema_name}.{table_name} limit 1",
    "pre_copy_script" : "Truncate table {schema_name}.{schema_name}.{table_name}"
}
