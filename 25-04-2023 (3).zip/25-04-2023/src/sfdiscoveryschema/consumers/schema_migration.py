"""
This code contains run for the schema migration
"""
import traceback
import logging
from datetime import datetime
from config import config, db, send_message
from libs.schema_util import get_schema_convert, get_ddl_script, execute_script, get_view_convert, create_views, \
    get_role_convert, create_roles, get_user_convert, create_users, job_run_fail_update, create_object_user_role, create_schema_user_role
from libs.util import abcr_job_run

log = logging.getLogger(config["logging"]["name"])


def schema_migration(data_kafka):
    try:
        job_id = data_kafka["job_id"]
        job_run_id = data_kafka["job_run_id"]
        sink_link_service_id = data_kafka["sink_link_service_id"]
        job_start = data_kafka["start"]
        tgt_db_vendor = data_kafka["tgt_db_vendor"]
        discovery_id = data_kafka["discovery_id"]
        tgt_database_server_nm = data_kafka["tgt_database_server_nm"]
        data = data_kafka["data"]
        force_create = data['force_create']
        job_name = data_kafka["job_name"]
        run_by = data_kafka["run_by"]
        user_id = data_kafka["user_id"]
        socket_flag = data_kafka["socket_flag"]
        pipeline_id = data_kafka["pipeline_id"]
        pipeline_run_id = data_kafka["pipeline_run_id"]

        # table schema migration
        try:
            data['database_table']
        except KeyError:
            data['database_table'] = []
        for item in data['database_table']:
            table_list = item['tables']
            schema_name = item['database']
            # schema convert
            batch_id = get_schema_convert(table_list, discovery_id, tgt_database_server_nm,
                                          job_run_id, tgt_db_vendor,schema_name)
            # schema definition
            if not batch_id:
                msg = {"message": "Schema conversion failed"}
                log.info(msg)
                job_run_fail_update(job_run_id)
            ddl_script_res = get_ddl_script(batch_id, schema_name, job_run_id, tgt_db_vendor)

            # schema execution
            if not ddl_script_res:
                msg = {"message": "DDL script creation failed"}
                log.info(msg)
                job_run_fail_update(job_run_id)

            # schema defination for grant ddl 
            # user_role_obj_ddl = create_object_user_role(table_list,discovery_id,batch_id,schema_name)
            # if not user_role_obj_ddl:
            #     msg = {"message": "DDL script creation failed"}
            #     log.info(msg)
            #     job_run_fail_update(job_run_id)

            # raise Exception()
            execute_script_res = execute_script(force_create, schema_name, batch_id,
                                                job_run_id, sink_link_service_id, user_id,
                                                socket_flag, pipeline_id, pipeline_run_id)

            if not execute_script_res:
                msg = {"message": "Execution of DDL script failed"}
                log.info(msg)
                job_run_fail_update(job_run_id)

        if tgt_db_vendor == "snowflake":
            try:
                data['database_view']
            except KeyError:
                data['database_view'] = []

            for item in data['database_view']:
                view_list = item['views']
                schema_name = item['database']
                # view schema convert
                batch_id = get_view_convert(view_list, schema_name, discovery_id,
                                            tgt_database_server_nm, job_run_id, tgt_db_vendor)
                if not batch_id:
                    msg = {"message": "View conversion failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)
                 # schema defination for grant ddl 

                schema_user_role_obj_ddl = create_schema_user_role(view_list,discovery_id,batch_id,schema_name)
                if not schema_user_role_obj_ddl:
                    msg = {"message": "DDL script creation failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)

                # view schema create
                create_views_res = create_views(force_create,batch_id, job_run_id, sink_link_service_id, user_id, socket_flag, pipeline_id, pipeline_run_id)
                if not create_views_res:
                    msg = {"message": "Execution of view DDL script failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)

            # role schema migration
            try:
                role_list = data['roles']
                # role schema convert
                batch_id = get_role_convert(role_list, discovery_id, tgt_database_server_nm,
                                            job_run_id, tgt_db_vendor)
                if not batch_id:
                    msg = {"message": "Role conversion failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)
                # role schema create
                create_roles_res = create_roles(force_create, batch_id, job_run_id,
                                                sink_link_service_id, user_id, socket_flag, pipeline_id, pipeline_run_id)
                if not create_roles_res:
                    msg = {"message": "Execution of roles DDL script failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)
            except KeyError:
                data['roles'] = []

            # users schema migration
            try:
                user_list = data['users']
                # user schema convert
                batch_id = get_user_convert(user_list, discovery_id, tgt_database_server_nm,
                                            job_run_id, tgt_db_vendor)
                if not batch_id:
                    msg = {"message": "User conversion failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)
                # user schema convert
                create_users_res = create_users(force_create, batch_id, job_run_id,
                                                sink_link_service_id, user_id, socket_flag, pipeline_id, pipeline_run_id)
                if not create_users_res:
                    msg = {"message": "Execution of users DDL script failed"}
                    log.info(msg)
                    job_run_fail_update(job_run_id)
            except KeyError:
                data['users'] = []

        # job run upadte
        query = {"job_run_id": job_run_id}
        run_status = db.job_run_detail.find(query, {"status": 1, "_id": 0})
        run_status = list(run_status)
        run_resp = db.job_run_detail.find(query, {"_id": 0,"object_type":1,"object_name":1,"object_parent":1,"status":1,"message":1})
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
        if any(item['status'] == 'Fail' or item['status'] == 'NotStarted' for item in run_status):
            resp = run_resp
            job_status = 'Fail'
            exec_log = {"message": "Job execution failed"}
            newvalues = {"$set": {"status": "Fail", "end_time": end_time,
                                  "end_time_str": end_time_str}}
        else:
            resp = run_resp
            job_status = 'Success'
            exec_log = {"message": "Job execution successful"}
            newvalues = {"$set": {"status": "Success", "end_time": end_time,
                                  "end_time_str": end_time_str}}
        if socket_flag:
            send_message("sf_schema_run_job_status", {"job_id": job_id, "status": job_status, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        db.job_run.update_one(query, newvalues)
        if config["ABCR"]["flag"] == "Y":
            configuration = ""
            abcr_status = abcr_job_run(configuration, end_time, exec_log, job_id, job_run_id,
                                       job_name, "migrating schema from teradata to snowflake",
                                       resp, run_by, job_start, job_status, config['ABCR']['schema'], " ")
            if abcr_status == "Fail":
                status = {"message": "Error while producing message on job run topic"}
                log.info(status)
                return
    except Exception:
        if socket_flag:
            send_message("sf_schema_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        job_run_fail_update(data_kafka["job_run_id"])
        log.error(traceback.format_exc())
        return False
