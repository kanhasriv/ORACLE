import pyodbc
import logging
import traceback
from config import config, db
log = logging.getLogger(config["logging"]["name"])


def job_register(data):
    try:
        job_register_id = data['jobRegisterID']
        update_query = {"jobRegisterID": job_register_id}
        if data["active"]:
            db.job_register.update(update_query, {"$set": data}, upsert=True)
            log.info("db.job_register.update(): update_query: {}".format(data))
            status = "Success"
        else:
            db.job_register.update(update_query, {'$set': {'active': False}})
            log.info("db.job_register.update(): update_query: {}".format(data))
            status = "Success"
    except Exception as e_error:
        log.error(e_error)
        status = "Fail"
    return status