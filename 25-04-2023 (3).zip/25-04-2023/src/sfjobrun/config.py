import os
import configparser
import pymongo
import boto3

config = configparser.ConfigParser()
session = boto3.session.Session()
if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"] == "development":
    config.read("dev-config.ini")
    mongo_client = pymongo.MongoClient(config["mongodb"]["host"])
else:
    config.read("config.ini")

# Creating AWS Secret Manager Client
client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region'],
    aws_access_key_id="AKIAWSJ3O4ZMD22ZOZLW",
    aws_secret_access_key="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")

# Updating config
config.update({
    "documentdb": {
            "hostname": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_hostname"])["SecretString"],
            "username": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_user"])["SecretString"],
            "password": client.get_secret_value(SecretId=config["aws_secrets"]["documentdb_password"])["SecretString"]
                    },
    "kafka": {
        "host": "20.172.185.47:9092",
        "topic_job_run" : config['kafkatopics']['topic_job_run']
    }

    })
    # Mongodb Server
    # Connecting to DocumentDB Server
db_client = pymongo.MongoClient("mongodb://ideatfdocdb:ideatfdocdb%21%23@localhost:27017/?authSource=admin&readPreference=primary&directConnection=true&ssl=true&tlsAllowInvalidCertificates=true&tlsAllowInvalidHostnames=true&retryWrites=false")

db = db_client[config["database"]["dbname"]]