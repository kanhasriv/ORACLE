"""
This service  run consumer for Job Run
"""
import logging
import logging.handlers
from kafka import KafkaConsumer
import json
from config import config
from libs.job_run import job_run

# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes=int(config["logging"]["logging_maxBytes"]),
            backupCount=int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)
# set consumer for Job Run
topic = config["kafka"]["topic_job_run"]
server = config["kafka"]["host"]
consumer_job_run = KafkaConsumer(topic, bootstrap_servers=[server])


log.info("Snowflake ABCR Job Run Service initialized Successfully")

for message in consumer_job_run:
    message = message.value
    data = json.loads(message)
    job_run(data)




