import traceback
import json
from config import config
import logging
from bson.json_util import dumps
import jwt
from libs.util import requests_retry_session
import time
import requests

log = logging.getLogger(config["logging"]["name"])


def validate_access_token(access_token, permissions):
    """
    Validate the access token
    """
    log.info("START access_token:{}, permissions: {}".format(access_token, permissions))

    # Check the none type before log as the none variable can not be appended as a string to log
    # If appended it throws NoneType exception
    if not access_token:
        log.error("Empty Access Token")
        return False

    access_token = str(access_token)

    url = config['um']['user_details']+"/userdata"

    payload = ""
    headers = {
        'Authorization': access_token,
        'Content-Type': 'application/json'
    }
    # Making a POST request to the API
    response = requests.request("POST", url, headers=headers, data=payload)

    if response.status_code != 200:
        log.error("No response fetched!")
        log.error(response.json())
        return False
    # Converting the response to json
    response = response.json()

    if not len(response["data"]):
        log.error("No user data found!")
        return False

    log.info("END")
    return response["data"]
