"""
This service contains APIs for the data discover
"""
import logging
import uuid
import sys
import re
import traceback
from datetime import datetime
import json
from ftplib import FTP
from flask import request, jsonify
import flask_api
import pyodbc
import threading
import pandas as pd
from bson.json_util import dumps
from libs.util import validate_json_schema, response,get_userdata,update_role_policy, link_service_status
from libs.access_token import validate_access_token
from libs import snowflake,error
from config import config, db, s3_client
from libs.secret_manager import create_secret, del_secret, put_secret, get_secret

# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
azure_consent_status = "azure_consent.request_status"
error_for_ftp = "error for ftp {}"
successful_update_message = "Record updated successfully"

idea_date_format = '%Y-%m-%d %H:%M:%S'
select_query = snowflake.link_service["select_query"]
snowflake_subscription_val = ["Standard Edition","Enterprise Edition","Business Critical Edition","Virtual Private Snowflake(VPS)"]
link_service_type_list = ["teradata DWH","teradata FTP","S3","snowflake DWH","oracle DWH"]


@app.route("/idea/services/migrationsf/link-service", methods=["GET"])
def get_link_service():
    """
    Get Link service
    """
    log.info("START")

    try:
        # # User authentication
        if not validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"]):
            return response(dumps(error.err_051), 401)

        data = request.args
        
        resp = list(db.link_service.find({"active": True},
                                         {"_id": 0, "db_password": 0, "key": 0, "active": 0,
                                          "insert_dttm_str": 0}))
        if len(resp) <= 0:
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND

        result = list(db.idea_snowflake_integration.find({"active": True}, {'_id': 0, 'active': 0}))
        
        # Checking for the integration which are active
        log.info("started getting integration status")
        for integration in result:
            if integration["aws_consent"]["request_status"] != "active":
                link_service_details = db.link_service.find_one(
                    {"link_service_id": integration["link_service_id"]},
                    {'_id': 0})

                # Fetching the secrets from the secret manager
                username = get_secret(
                    link_service_details["link_service_id"] + "-username")
                password = get_secret(
                    link_service_details["link_service_id"] + "-password")

                # Making the connection string to connect with snowflake account
                db_conn_string = config['snowflake']["conn"].format(
                    hostname=link_service_details["db_hostname"],
                    uid=username,
                    pwd=password,
                    warehouse=config['snowflake']['link_dwh'])
                con = pyodbc.connect(db_conn_string)
                cursor = con.cursor()
                query = snowflake.link_service["check_permission"].format(integration["stage_name"])

                # Executing snowflake query to check the integration status
                try:
                    cursor.execute(
                        "USE DATABASE {}".format(config['snowflake']["database_snowflake"]))
                    cursor.execute(query)
                    con.close()
                    integration["aws_consent"]["request_status"] = "active"
                    db.idea_snowflake_integration.update_one(
                        {"link_service_id": integration["link_service_id"]},
                        {"$set": {"aws_consent.request_status": "active"}})
                    db.link_service.update_one(
                        {"link_service_id": integration["link_service_id"]},
                        {"$set": {"is_active": "Y"}})

                except Exception as e_error:
                    log.info(e_error)
                    db.idea_snowflake_integration.update_one(
                        {"link_service_id": integration["link_service_id"]},
                        {"$set": {"aws_consent.request_status": "inactive"}})
                    db.link_service.update_one(
                        {"link_service_id": integration["link_service_id"]},
                        {"$set": {"is_active": "N"}})

        query = {"active": True}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"link_service_name": filter_param},
                {"db_hostname": filter_param},
                {"db_user": filter_param},
                {"s3_bucket_name": filter_param},
                {"shared_path": filter_param},
                {"snowflake_subscription_type": filter_param},
                {"db_authentication_type": filter_param},
                {"discovery_warehouse_type": filter_param},
                {"schema_migration_warehouse_type": filter_param},
                {"data_migration_warehouse_type": filter_param},
                {"created_by": filter_param}
            ]
        resp = list(db.link_service.find(query,
                                         {"_id": 0, "key": 0, "active": 0,
                                          "insert_dttm_str": 0,"modified_at_str":0}))
    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR
    log.info("END")
    return jsonify({"status": "Success", "category": "Snowflake_Migration", "error_code": "",
                    "message": "Link service fetched successfully", "data": resp}),200


@app.route("/idea/services/migrationsf/link-service", methods=["POST"])
@validate_json_schema
def create_link_service():
    # Link service
    log.info("START")
    # Get json data
    data = request.get_json()

    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)

    user_data = get_userdata(access_details)

    try:
        link_service_type = data["link_service_type"]
        db_vendor = link_service_type.lower().split(" ")[0].strip()

        if link_service_type not in link_service_type_list:
            return jsonify(error.err_0100), 400

        if db_vendor != "s3":
            mig_type = link_service_type.split(" ")[1].strip()
            if mig_type not in ["FTP", "DWH"] :
                return jsonify(error.err_0100), 400

        # Checking for valid entry in ftp link service
        if link_service_type == link_service_type_list[1]:
            for key in data:
                if key not in ["db_hostname", "db_user","link_service_name","link_service_type", "shared_path","db_password","port"]:
                    log.info("invalid entry {} for teradata FTP link service".format(key))
                    return jsonify(error.err_062), 400
                else:
                    if data["shared_path"] is None or not (data["shared_path"] and not data["shared_path"].isspace()): 
                            shared_path = config['ftp']['shared_path']
                            data["shared_path"] = config['ftp']['shared_path']

        # Checking for a valid entry in teradata dwh lik service
        elif link_service_type == link_service_type_list[0]:
            for key in data:
                if key not in ["db_hostname","link_service_name","link_service_type", "db_user","db_password"]:
                    log.info("Invalid entry {} for terdata DWH link service".format(key))
                    return jsonify(error.err_062), 400
                    
        elif link_service_type == link_service_type_list[3]:
            for key in data:
                if key not in ["db_hostname", "db_user", "link_service_name", "link_service_type",
                               "data_migration_warehouse_type",
                               "db_authentication_type", "discovery_warehouse_type",
                               "schema_migration_warehouse_type", "snowflake_subscription_type","db_password"]:
                    log.info("Invalid entry {} for snowflake link service".format(key))
                    return jsonify(error.err_062), 400

                if key == "snowflake_subscription_type" and data[key] not in snowflake_subscription_val:
                    log.info("Invalid Snowflake subscription type")
                    return jsonify(error.err_057), 400
        elif link_service_type == link_service_type_list[4]:
            for key in data:
                if key not in ["db_hostname","db_user","link_service_name","link_service_type","db_password","port","sid","database"]:
                    log.info("Invalid entry {} for oracle DWH link service".format(key))
                    return jsonify(error.err_062),400


        if db_vendor == "s3":

            # Validating required details
            for key in data:
                if key not in ["s3_bucket_name", "link_service_name", "link_service_type"]:
                    log.info("Invalid entery {} for S3 link service".format(key))
                    return jsonify(error.err_062), 400

        link_service_name = data["link_service_name"]

        # Checking for unique link service name 
        resp1 = db.link_service.find_one(
            {"$and": [{"link_service_name": link_service_name}, {"active": True}]})
        if resp1 is not None:
            log.info("Duplicat link service name")
            return jsonify(error.err_069),409

        data["Insert_DTTM"] = int(datetime.utcnow().timestamp())
        data["Insert_DTTM_STR"] = datetime.fromtimestamp(data["Insert_DTTM"]).strftime(idea_date_format)
        data["created_by"]= user_data["name"]
        link_service_id = str(uuid.uuid4())
        data["link_service_id"] = link_service_id

         # Creating link service for s3                
        if db_vendor == "s3":

            s3_bucket_name = data["s3_bucket_name"]

            # Checking if there is any s3 service with the same bucket and is active
            resp_s3 = db.link_service.find_one(
                {"$and": [{"s3_bucket_name": s3_bucket_name}, {"active": True}]})

            if resp_s3 is not None:
                log.info('S3 bucket name already exist')
                return jsonify(error.err_059),409
            
            try:
                # Checking if the bucket exists in the s3
                resp = s3_client.list_objects_v2(Bucket=s3_bucket_name)
            except:
                log.error(traceback.format_exc())
                return jsonify(error.err_098), 403

            data["active"] = True
            data["modified_by"] = ""
            data["modified_at"] = ""
            data = {key.lower(): value for key, value in data.items()}
            #insert
            resp = db.link_service.insert_one(data)

            log.info("END")
            return jsonify({"status": "Success", "category": "Snowflake_Migration", "error_code": "",
                    "message": "Record inserted successfully", "data": ""}), 200

        db_hostname = data["db_hostname"]
        db_user = data["db_user"]
        db_password = data["db_password"]
		
		# Checking for the unique combination of relevant details
        if data["link_service_type"] == link_service_type_list[1]:
            shared_path = re.sub("(\/+)","/", "/"+data["shared_path"]+"/")
            data["shared_path"] = shared_path
            resp = db.link_service.find_one({"$and": [{"db_hostname": db_hostname}, {"active": True},{"shared_path": data["shared_path"]}]})
            if resp is not None:
                log.info("hostname, username and shared_path already there")
                return jsonify(error.err_056), 409
        else:
            resp = db.link_service.find_one({"$and": [{"db_hostname": db_hostname,"db_user":db_user}, {"active": True}]})
            if resp is not None:
                log.info("hostname and username already there")
                return jsonify(error.err_058),409

        try:

			# Making the connection strings for snowflake and teradata DWH
            if mig_type == "DWH":
                if db_vendor == "snowflake":
                    db_conn_string = config[db_vendor]["conn"].format(hostname=db_hostname,
                                                                        uid=db_user,
                                                                        pwd=db_password,
                                                                        warehouse=config['snowflake']['discover_dwh'])
                elif db_vendor == "teradata":
                    db_conn_string = config[db_vendor]["conn"].format(hostname=db_hostname,
                                                                        uid=db_user,
                                                                        pwd=db_password)
                else:
                    sid=data["database"]
                    port=data["port"]
                    db_conn_string=config[db_vendor]["conn"].format(hostname=db_hostname,
                                                                    uid=db_user,
                                                                    pwd=db_password,
                                                                    port=port,
                                                                    sid=sid)
                con = pyodbc.connect(db_conn_string)
                pd.read_sql_query(select_query, con)
            
            # Making the connection string for Teradata FTP
            elif mig_type == "FTP":
                try:
                    # Trying  to connect to ftp server
                    port = data["port"]
                    con = FTP()
                    con.connect(db_hostname,port)
                    con.login(db_user, db_password)
                except Exception as e_error:
                        log.info(error_for_ftp.format(e_error))
                        return jsonify(error.err_052),403
                try:
                    con.cwd(shared_path)
                except Exception as e_error:
                    log.info(error_for_ftp.format(e_error))
                    return jsonify(error.err_053),403
            if con is None:
                log.info("connection failed for the link service")
                return jsonify(error.err_098),403
            else:
                if db_vendor == "snowflake":                              
                    resp_snowflake = db.link_service.find_one({"$and": [{"db_hostname": db_hostname}, {"active": True}]})

                    # Integration variable value
                    integration_name = config['snowflake']['integration_name']
                    stage_type = config['snowflake']['stage_type']
                    storage_provider = config['snowflake']['storage_provider']
                    enabled = config['snowflake']['enabled']
                    storage_aws_role_arn = config['snowflake']['storage_aws_role_arn']
                    stage_name = config['snowflake']['stage_name']
                    storage_allowed_locations = config['snowflake']['storage_allowed_locations']
                    file_format = config['snowflake']['file_format']
                    schema = config['snowflake']['schema']
                    file_format_name = config['snowflake']['file_format']
                    file_format_name_ftp = config['snowflake']['file_format_ftp']

                    # Creating snowflake instance no other ls is active
                    if resp_snowflake is None:
                        # Reading details and creating snowflake query
                     
                        discovery_warehouse_name = config['snowflake']['discover_dwh']
                        schema_warehouse_name = config['snowflake']['schema_migration_dwh']
                        data_warehouse_name = config['snowflake']['data_migration_dwh']
                        database_snowflake = config['snowflake']['database_snowflake']

                        # Making warehouse and database query
                      
                        # create integration query
                        integration_query = snowflake.sf_link_all["integration_query"]
                        # create file formate query
                        file_formate_query = snowflake.sf_link_all["file_formate_query"]
                        # create file formate query for FTP
                        file_formate_query_ftp = snowflake.sf_link_all["file_formate_query_ftp"]
                        # create stage query
                        stage_query = snowflake.sf_link_all["stage_query"]
                        # formating the query
                        
                        file_formate_query = file_formate_query.format(
                            database_snowflake=database_snowflake, schema=schema,
                            file_format_name=file_format_name)
                        file_formate_query_ftp = file_formate_query_ftp.format(
                            database_snowflake=database_snowflake, schema=schema,
                            file_format_name_ftp=file_format_name_ftp)
                        stage_query = stage_query.format(stage_name=stage_name,
                                                            integration_name=integration_name,
                                                            storage_allowed_locations=storage_allowed_locations,
                                                            file_format = file_format)
                       
                        integration_query = integration_query.format(integration_name=integration_name,
                                                                        stage_type=stage_type,
                                                                        storage_provider=storage_provider,
                                                                        enabled=enabled,
                                                                        storage_aws_role_arn = storage_aws_role_arn,
                                                                        storage_allowed_locations=storage_allowed_locations)

                       
                       
                       
                        cursor = con.cursor()

                        # Executing snowflake object creation queries
                        try:
                           
                            idea_database = "use {database}".format(database=config['snowflake']['database_snowflake'])
                            cursor.execute(idea_database)
                            cursor.execute(snowflake.sf_link_all['create_schema_query'].format(schema_snowflake = config['snowflake']['idea_schema']))
                            cursor.execute(file_formate_query)
                            cursor.execute(file_formate_query_ftp)
                            cursor.execute(integration_query)
                            cursor.execute(stage_query)
                            log.info("Snowflake integration_query : {}".format(integration_query))
                            log.info(" file formate query :{}".format(file_formate_query))
                            log.info("snowflake stage query : {}".format(stage_query))
                            log.info(" file formate query ftp :{}".format(file_formate_query_ftp))
                        except Exception as e_error:
                            log.info("Creating integration failed")
                            log.error(traceback.format_exc())
                            return jsonify(error.err_055), 400

                    # Updating the integration details
                    try:
                        # Fetching the stage related details from snowflake
                        describe_query = "DESC INTEGRATION {integration_name};".format(
                            integration_name=integration_name)
                        df = pd.read_sql_query(describe_query, con)
                        integration_data = {
                            "link_service_id": link_service_id,
                            "integration_name": integration_name,
                            "stage_name": stage_name,
                            "stage_type": stage_type,
                            "active": True
                        }

                        # Checking and storing the stage related details
                        for item in df.to_dict('records'):
                            if item['property'] == "STORAGE_AWS_IAM_USER_ARN":
                                integration_data["aws_consent"] = {
                                    "STORAGE_AWS_ROLE_ARN": item['property_value'],
                                    "request_status": 'inactive'
                                }
                            elif item['property'] == "STORAGE_AWS_EXTERNAL_ID":
                                integration_data["aws_consent"]["STORAGE_AWS_EXTERNAL_ID"]= item['property_value']
                            elif item['property'] == "STORAGE_AWS_ROLE_ARN":
                                integration_data["aws_consent"]["STORAGE_AWS_IAM_USER_ARN"]= item['property_value']
                            else:
                                integration_data[item['property'].lower()] = item['property_value']
                        if not update_role_policy(integration_data):
                            log.info("Failed to update the role policy")
                            return jsonify(error.err_093), 403
                        db.idea_snowflake_integration.insert_one(integration_data)
                        data["is_active"] = "N"
                    except Exception as e_error:
                        log.info("Stage creation failed : {}".format(e_error))
                        return jsonify(error.err_055), 400
                    
                con.close()

        except pyodbc.Error:

            log.info("pyodbc error occured")
            log.error(traceback.format_exc())

            return jsonify(error.err_098), 403

        log.info("db.link_service.insert(): data: {}".format(data))

        # Storing secrets in secrete manager
        resp1 = create_secret(data["link_service_id"] + '-username', data["db_user"])
        log.info("set secret success for username")
        resp2 = create_secret(data["link_service_id"] + '-password',data["db_password"])
        log.info("set secret success for password")
        data["active"] = True
        data["modified_by"] = ""
        data["modified_at"] = ""
        data = {key.lower(): value for key, value in data.items()}
        if data["link_service_type"] == link_service_type_list[3]:
            values = {
                    "snowflake_hostname": data["db_hostname"],
                    "snowflake_username": data["db_user"],
                    "snowflake_password": data["db_password"]
                    }
            values = json.dumps(values)
            log.info("setting secrets for ETL")

            # Putting secrets for etl
            try:
                put_secret("etl-snowflake-cred", str(values))
                log.info("setting secrets for ETL Done")
            except Exception:
                create_secret( "etl-snowflake-cred", values)
                log.info("setting secrets for ETL Done")

        # Deleting details that should not be stored in mongo
        del data["db_password"]
        if data["link_service_type"]==link_service_type_list[3]:
            data['discovery_warehouse_type']= discovery_warehouse_name
            data['schema_migration_warehouse_type']= schema_warehouse_name
            data['data_migration_warehouse_type']= data_warehouse_name
        resp = db.link_service.insert_one(data)
    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({"status": "Success", "category": "Snowflake_Migration", "error_code": "",
                    "message": "Record inserted successfully", "data": ""}), 200


@app.route("/idea/services/migrationsf/link-service", methods=["DELETE"])
@validate_json_schema
def delete_link_service():
    # Link service
    log.info("START")
    
    # Validating the access token 
    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)

    # Get json data
    data = request.args
    user_data = get_userdata(access_details)
    if not user_data:
        return response(dumps(error.err_051), 401)

    if user_data["user_type"].lower() != "admin":
        return jsonify(error.err_065), 403
    try:
        # Checking for the record in our collections
        query = {"link_service_id": data["link_service_id"]}
        log.info("db.link_service.find_one(): query: {}".format(query))
        resp = db.link_service.find_one({"$and": [query, {"active": True}]})
        if resp is None:
            return jsonify(error.err_088), flask_api.status.HTTP_400_BAD_REQUEST

        db_vendor = resp["link_service_type"].lower().split(" ")[0].strip()
		
		# Reading the secrets and droping instances from snowflake account
        if db_vendor == "snowflake":
            log.info("reding username and password from kv")
            username = get_secret(data["link_service_id"] + "-username")
            log.info("accessed user successfully")
            password = get_secret(data["link_service_id"] + "-password")
            log.info("accessed password successfully")

            hostname = resp["db_hostname"]
            db_conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                              pwd=password, warehouse=config['snowflake']['discover_dwh'])
            con = pyodbc.connect(db_conn_string)
            pd.read_sql_query(select_query, con)

            # Dropping all the snowflake instances
            if con:
                query_db = {"db_hostname":resp["db_hostname"]}
                resp_db = list(db.link_service.find({"$and": [query_db, {"active": True}]}))
                if len(resp_db)<2:
                    try:
                        cursor = con.cursor()
                        integration_name = config['snowflake']['integration_name']
                        database_snowflake = config['snowflake']['database_snowflake']
                        discovery_warehouse_name = config['snowflake']['discover_dwh']
                        schema_warehouse_name = config['snowflake']['schema_migration_dwh']
                        data_warehouse_name = config['snowflake']['data_migration_dwh']
                        # drop query
                        drop_data_wh_query = snowflake.sf_link_all["drop_data_wh_query"]
                        drop_schema_wh_query = snowflake.sf_link_all["drop_schema_wh_query"]
                        drop_discovery_wh_query = snowflake.sf_link_all["drop_discovery_wh_query"]
                        drop_database_query = snowflake.sf_link_all["drop_database_query"]
                        drop_sf_integration_query = snowflake.sf_link_all["drop_sf_integration_query"]
                        # formating the drop query
                        drop_data_wh_query = drop_data_wh_query.format(
                            data_warehouse_name=data_warehouse_name)
                        drop_schema_wh_query = drop_schema_wh_query.format(
                            schema_warehouse_name=schema_warehouse_name)
                        drop_discovery_wh_query = drop_discovery_wh_query.format(
                            discovery_warehouse_name=discovery_warehouse_name)
                        drop_database_query = drop_database_query.format(
                            database_snowflake=database_snowflake)
                        drop_sf_integration_query = drop_sf_integration_query.format(
                            integration_name=integration_name)

                        # loging the drop query
                        log.info("drop_data_wh_query= {}".format(drop_data_wh_query))
                        log.info("drop_schema_wh_query= {}".format(drop_schema_wh_query))
                        log.info("drop_discovery_wh_query= {}".format(drop_discovery_wh_query))
                        log.info("delete_database_query= {}".format(drop_database_query))
                        log.info("drop_sf_integration_query = {}".format(drop_sf_integration_query))
                        # executing the drop query
                        # cursor.execute(drop_data_wh_query)
                        # cursor.execute(drop_schema_wh_query)
                        # cursor.execute(drop_discovery_wh_query)
                        # cursor.execute(drop_database_query)
                        cursor.execute(drop_sf_integration_query)
                    except Exception as e_error:
                        log.error(traceback.format_exc())
                        log.info("exception occured {}".format(e_error))
                        return jsonify({"status": "Fail", "category": "Snowflake_Migration",
                                        "error_code": "IDEA_ERR_087",
                                        "message": "Record not deleted", "data": ""}), 500

            else:
                return jsonify({"status": "Fail", "category": "Snowflake_Migration",
                                "error_code": "IDEA_ERR_087",
                                "message": "Record not deleted", "data": ""}), 500
                
            con.close()

        # Deleting it from secret manager
        if db_vendor != "s3":
            log.info("delet username secret started")
            del_secret(data["link_service_id"] + '-username')
            log.info("username deleted")
            log.info("delet username secret started")
            del_secret(data["link_service_id"] + '-password')
            log.info("password deleted")

        db.job_registry.update_many({"link_service_id": data["link_service_id"]},
                                    {"$set": {"active": False}})
        db.job_registry.update_many({"sink_link_service_id": data["link_service_id"]},
                                    {"$set": {"active": False}})
        db.job_registry.update_many({"source_link_service_id": data["link_service_id"]},
                                    {"$set": {"active": False}})
        db.idea_snowflake_integration.update_one(query, {"$set": {"active": False}})
        resp = db.link_service.update_one(query, {"$set": {"active": False}})
        log.info("db.link_service.update_one(): resp: {}".format(resp.raw_result))
        if resp.raw_result['n'] == 0:
            return jsonify(error.err_087), 500
    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify({"status": "Success", "category": "Snowflake_Migration", "error_code": "",
                    "message": "Record deleted successfully", "data": ""}), 200


@app.route("/idea/services/migrationsf/test-connection", methods=["POST"])
@validate_json_schema
def test_connection():
    # Test teradata/snowflake connection
    log.info("START")

    try:
        data = request.get_json()
        
        # Validate Access token
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
        if not access_details:    
            return response(dumps(error.err_051), 401)
                 
        query = {"link_service_id": data["link_service_id"]}
        log.info("db.link_service.find_one(): query: {}".format(query))

        # Checking active status of link service
        resp = db.link_service.find_one({"$and": [query, {"active": True}]})
        if resp is None:
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND

        db_vendor = resp["link_service_type"].lower().split(" ")[0].strip()
        if db_vendor!= "s3":
            if "username" not in data or "password" not in data:
                log.info("missing filed username or password")
                return jsonify(error.err_074),400 
            if "s3_bucket_name" in data:
                log.info("S3 bucket name is not required")
                return jsonify(error.err_074),400 

            mig_type = resp["link_service_type"].split(" ")[1].strip()
            hostname = resp["db_hostname"]
            username = data["username"]
            password = data["password"]
        else:
            if ("username" in data) or ("password" in data):
                log.info("username or password is not required")
                return jsonify(error.err_074),400 
            if "s3_bucket_name" not in data:
                log.info("missing filed s3_bucket_name")
                return jsonify(error.err_074),400 
            s3_bucket_name = data["s3_bucket_name"]

        # Connecting with FTP server
        if db_vendor == "teradata" and mig_type == "FTP":
            try:
                port = resp["port"]
                con = FTP()
                con.connect(hostname,port)
                con.login(username, password)
                # con = FTP(hostname, username, password)
                status = {"status": "Success", "category": "Snowflake_Migration",
                          "error_code": "",
                          "message": "Test connection successful", "data": ""}
                error_flask = 200
            except Exception as e_error:
                log.info(error_for_ftp.format(e_error))
                return jsonify(error.err_052),500
        elif db_vendor == "s3":
            try:
                # Checking if the bucket exists in the s3
                resp = s3_client.list_objects_v2(Bucket=s3_bucket_name)
                status = {"status": "Success", "category": "Snowflake_Migration",
                          "error_code": "",
                          "message": "Test connection successful", "data": ""}
                error_flask = 200
            except:
                log.error(traceback.format_exc())
                return jsonify(error.err_098), 403
        else:
            if db_vendor == 'snowflake':
                conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                               pwd=password, warehouse=config['snowflake']['discover_dwh'])
            elif db_vendor=="teradata":
                conn_string = config[db_vendor]["conn"].format(hostname=hostname,
                                                               uid=username,
                                                               pwd=password)
            elif db_vendor=="oracle":
                port=resp["port"]
                sid=resp["database"]
                conn_string=config[db_vendor]["conn"].format(hostname=hostname,
                                                            uid=username,
                                                            pwd=password,
                                                            port=port,
                                                            sid=database)                 
            try:
                con = pyodbc.connect(conn_string)
                pd.read_sql_query(select_query, con)
                if con:
                    status = {"status": "Success", "category": "Snowflake_Migration",
                              "error_code": "",
                              "message": "Test connection successful", "data": ""}
                    error_flask = 200
                    con.close()
                else:
                    status = error.err_098
                    error_flask = 403

            except pyodbc.Error:
                status = error.err_098
                error_flask = 403
                log.error(traceback.format_exc())

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify(status), error_flask


@app.route("/idea/services/migrationsf/link-service-edit", methods=["POST"])
@validate_json_schema
def edit_link_service():
    """
    editing link service
    """
    log.info("START")
    try:

        # Validating the access token
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
        if not access_details:    
            return response(dumps(error.err_051), 401)

        user_data = get_userdata(access_details)
        if user_data["user_type"].lower() != "admin":
            return jsonify(error.err_065), 403
        # Get json data

        data = request.get_json()


        # Checking for active status of link service
        link_service_id = data["link_service_id"]

        query = {"link_service_id": link_service_id}
        
        log.info("db.link_service.find_one():query: {query}".format(query=query))
        resp = db.link_service.find_one({"$and": [query, {"active": True}]})
        if resp is None:
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND
        
        # Reading username and password from kv
        if resp["link_service_type"] !="S3":
            log.info("getting secret from kv started")
            username_kv = get_secret(link_service_id + "-username")
            log.info("got username")
            password_kv = get_secret(link_service_id + "-password")
            log.info("got password")
            resp["db_user"] = username_kv
            resp["db_password"] = password_kv
            mig_type = resp["link_service_type"].split(" ")[1].strip()

        # Check for the fields that can be updated
        for key in data:
            if key == "db_hostname" or key == "link_service_type" or key =="discovery_warehouse_type" or key =="schema_migration_warehouse_type" or key=="data_migration_warehouse_type" or key =='snowflake_subscription_type':
                status = error.err_0104
                return jsonify(status), 400
                
            if key == "snowflake_subscription_type" and data[key] not in snowflake_subscription_val:
                        return jsonify(error.err_057), 400

            # Checking for duplicate link service name
            if key== "link_service_name":
                resp1 = db.link_service.find_one(
                        {"$and": [{"link_service_name": data["link_service_name"]}, {"active": True}]})
                if resp1 is not None:
                    return jsonify(error.err_069),409
            resp[key] = data[key]

        db_vendor = resp["link_service_type"].lower().split(" ")[0].strip()

        # Checking for field that can be updated for different link_service
        if db_vendor != "snowflake" and ("snowflake_subscription_type" in data or "W_IDEA_MIGRATION_DATA_XS" in data or "W_IDEA_MIGRATION_DATA_XS" in data or "W_IDEA_MIGRATION_DATA_M" in data or "db_authentication_type" in data):
            status = error.err_0104
            return jsonify(status), 400

        if resp["link_service_type"] != link_service_type_list[1] and "shared_path" in data:
            status = error.err_0104
            return jsonify(status), 400
        
        if resp["link_service_type"] !=link_service_type_list[2] and "account_key" in data:
            status=error.err_0104
            return jsonify(status), 400
        
        if resp["link_service_type"]==link_service_type_list[2] and ("db_user" in data or "db_password" in data):
            status=error.err_0104
            return jsonify(status),400

        

        
        # Updating the shared path with default value if deleted from ls 
        if resp["link_service_type"] == link_service_type_list[1] and "shared_path" in data:
            if data["shared_path"] is None or not (data["shared_path"] and not data["shared_path"].isspace()):
                path = config['ftp']['shared_path']
                resp["shared_path"] = config['ftp']['shared_path']
            else:
                path = re.sub("(\/+)", "/","/"+ data["shared_path"]+"/")
            resp_shared_path = db.link_service.find_one({"$and": [{"db_hostname": resp["db_hostname"]}, {"active": True},{"shared_path": path}]})
            if resp_shared_path is not None:
                return jsonify(error.err_056),409
        
        if db_vendor == "s3":
            for key in data:
                if key not in ["link_service_id","link_service_name"]:
                    status = error.err_0104
                    return jsonify(status), 400
            try: 
                resp["modified_by"] = user_data["name"]
                resp["modified_at"] = int(datetime.utcnow().timestamp())
                resp["modified_at_str"] = datetime.fromtimestamp(resp["modified_at"]).strftime(idea_date_format)
                for key in resp:
                            db.link_service.update_one({"link_service_id": link_service_id},
                                                    {"$set": {key: resp[key]}})
                log.info("record successfully updated")
                status = {"status": "Success", "category": "Snowflake_Migration",
                              "error_code": "",
                              "data": "",
                              "message": successful_update_message}
                return jsonify(status),200
            except Exception:
                log.error(traceback.format_exc())
                status = error.err_095
                return jsonify(status), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR 

        hostname = resp["db_hostname"]
        username = resp["db_user"]
        password = resp["db_password"]
		
		# Making the connection string
        if db_vendor == 'snowflake':
            db_conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                              pwd=password, warehouse=config['snowflake']['discover_dwh'])
        else:
            if db_vendor == 'teradata' and mig_type == "DWH":
                db_conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                                  pwd=password)
            elif db_vendor == "oracle" and mig_type=="DWH":
                port=resp['port']
                sid=resp["database"]
                db_conn_string=config[db_vendor]["conn"].format(hostname=hostname,uid=username,pwd=password,port=port,sid=database)
        
        try:

            # Checking and updating the FTP details
            if db_vendor == 'teradata' and mig_type == "FTP":
                shared_path = re.sub("(\/+)", "/", "/"+resp["shared_path"]+"/")
                resp["shared_path"] = shared_path
                port = resp["port"]
                try:
                    ftp = FTP()
                    ftp.connect(hostname,port)
                    ftp.login(username, password)
                    if "shared_path" in data:
                        try:
                            ftp.cwd(shared_path)
                        except Exception as e_error:
                            status = error.err_070
                            return jsonify(status), 400

                    # Updating the secrets in secret manager
                    log.info("updating secret started")
                    put_secret(data["link_service_id"] + '-username',resp["db_user"])
                    log.info("username updated")
                    put_secret(data["link_service_id"] + '-password',resp["db_password"])
                    log.info("password updated")
                    del resp["db_password"]
                    # resp["modified_by"] = user_data["name"]
                    resp["modified_at"] = int(datetime.utcnow().timestamp())
                    resp["modified_at_str"] = datetime.fromtimestamp(resp["modified_at"]).strftime('%Y-%m-%d %H:%M:%S')
                    for key in resp:
                        db.link_service.update_one({"link_service_id": link_service_id},
                                                   {"$set": {key: resp[key]}})
                    status = {"status": "Success", "category": "Snowflake_Migration",
                              "error_code": "",
                              "data": "",
                              "message": successful_update_message}
                    error_flask = 200
                except Exception as e_error:
                    status = error.err_0105
                    return jsonify(status), 400
            else:
                # Updating the details related to snowflake DWH and teradata DWH
                con = pyodbc.connect(db_conn_string)
                pd.read_sql_query(select_query, con)
                if con:
                

                    status = {"status": "Success", "category": "Snowflake_Migration",
                              "error_code": "",
                              "data": "",
                              "message": successful_update_message}
                    error_flask = 200

                    log.info("updating secret started")
                    put_secret(data["link_service_id"] + '-username', resp["db_user"])
                    log.info("username updated")
                    put_secret(data["link_service_id"] + '-password', resp["db_password"])
                    log.info("password updated")

                    # Updating Secret for ETL
                    if resp["link_service_type"] == link_service_type_list[3]:
                        values = {
                                "snowflake_hostname": resp["db_hostname"],
                                "snowflake_username": resp["db_user"],
                                "snowflake_password": resp["db_password"]
                                }
                        values = json.dumps(values)
                        log.info("setting secrets for ETL")
                        put_secret("etl-snowflake-cred", values)
                        log.info("setting secrets for ETL Done")
                    del resp["db_password"]
                    resp["modified_by"] = user_data["name"]
                    resp["modified_at"] = int(datetime.utcnow().timestamp())
                    resp["modified_at_str"] = datetime.fromtimestamp(resp["modified_at"]).strftime('%Y-%m-%d %H:%M:%S')
                    for key in resp:
                        db.link_service.update_one({"link_service_id": link_service_id},
                                                   {"$set": {key: resp[key]}})
                    log.info("record successfully updated")
                    con.close()

                else:
                    status = error.err_098
                    error_flask = 403

        except pyodbc.Error:
            status = error.err_098
            error_flask = 403

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    return jsonify(status), error_flask


@app.route("/idea/services/migrationsf/snowflake-integration-service", methods=["GET"])
def get_snowflake_integration_service():
    log.info("START")
    try:
        # Validating the access token
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
        if not access_details:    
            return response(dumps(error.err_051), 401)


        result = list(db.idea_snowflake_integration.find({"active": True}, {'_id': 0, 'active': 0}))
        if len(result) == 0:
            return jsonify(error.err_088), 404

        for integration in result:
            if integration["aws_consent"]["request_status"] != "active":
                link_service_details = db.link_service.find_one(
                    {"link_service_id": integration["link_service_id"]},
                    {'_id': 0})

                username = get_secret(
                    link_service_details["link_service_id"] + "-username")
                password = get_secret(
                    link_service_details["link_service_id"] + "-password")

                db_conn_string = config['snowflake']["conn"].format(
                    hostname=link_service_details["db_hostname"],
                    uid=username,
                    pwd=password,
                    warehouse=config['snowflake']['link_dwh'])
                con = pyodbc.connect(db_conn_string)
                cursor = con.cursor()
                con.close()
                query = snowflake.link_service["check_permission"].format(integration["stage_name"])
                try:
                    cursor.execute(
                        "USE DATABASE {}".format(config['snowflake']["database_snowflake"]))
                    cursor.execute(query)
                    integration["aws_consent"]["request_status"] = "active"
                    db.idea_snowflake_integration.update_one(
                        {"link_service_id": integration["link_service_id"]},
                        {"$set": {"aws_consent.request_status": "active"}})
                except Exception as e_error:
                    log.info(e_error)

        log.info("END")
        return jsonify({"status": "Success",
                        "category": "Snowflake_Migration",
                        "error_code": "",
                        "message": "Get snowflake integrations successful",
                        "data": result}), 200

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR


@app.route("/idea/services/migrationsf/snowflake-integration-service", methods=["POST"])
@validate_json_schema
def activate_snowflake_integration_service():
    log.info("START")
    try:
        data = request.get_json()

        # Validating the access token
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
        if not access_details:    
            return response(dumps(error.err_051), 401)

        # Fetching the integration related details of active snowflake link service
        integration_data = db.idea_snowflake_integration.find_one(
            {"link_service_id": data["link_service_id"],
             "active": True})
        if not bool(integration_data):
            return jsonify(error.err_088), 404

        log.info("END")
        result = {"status": "Success",
                  "category": "Snowflake_Migration",
                  "error_code": "",
                  "message": "Get activation URL successful",
                  "data":
                      {"STORAGE_AWS_EXTERNAL_ID": integration_data["aws_consent"]["STORAGE_AWS_EXTERNAL_ID"],
                      "STORAGE_AWS_ROLE_ARN":integration_data["aws_consent"]["STORAGE_AWS_ROLE_ARN"] }
                  }
        return jsonify(result), 200

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR


@app.route("/idea/services/migrationsf/snowflake-authentication-type", methods=["GET"])
def db_authentication_type():
    """
        This API get the list of snowflake authentication type
        :return: json response
        """
    log.info("START")
    # Validating the access token
    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Snowflake authentication type fetched successfully",
            "data": {"db_authentication_type": ["Snowflake Authentication"]}}

    log.info("END")
    return jsonify(resp), 200

@app.route("/idea/services/migrationsf/snowflake-subscription-type", methods=["GET"])
def snowflake_subscription_type():
    """
        This API get the list of snowflake subscription type
        :return: json response
        """
    log.info("START")
    # Validating the access token
    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Snowflake subscription type fetched successfully",
            "data": {"snowflake_subscription_type": ["Standard Edition","Enterprise Edition","Business Critical Edition","Virtual Private Snowflake(VPS)"]}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/link-service-type", methods=["GET"])
def link_service_type():
    """
        This API get the list of link service type
        :return: json response
        """
    log.info("START")
    # Validating the access token
    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)


    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Link service type fetched successfully",
            "data": {"link_service_type": link_service_type_list}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/link-service-warehouse-type", methods=["GET"])
def link_service_warehouse_type():
    """
        This API get the list of warehouse size
        :return: json response
        """
    log.info("START")
    # Validating the access token
    access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
    if not access_details:    
        return response(dumps(error.err_051), 401)

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "Link service warehouse-type fetched successfully",
            "data": {"snowflake_warehouse_type": ["XSMALL","SMALL","MEDIUM","LARGE","XLARGE","XXLARGE","XXXLARGE","X4LARGE"]}}
    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/link-service-status", methods=["GET"])
def get_link_service_status():
    """
    Get Link service status
    """
    log.info("START")

    try:
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["Link_service"])
        if not access_details:    
            return response(dumps(error.err_051), 401)

        data = request.args
        query = {"active": True}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"link_service_name": filter_param},
                {"db_hostname": filter_param},
                {"db_user": filter_param},
                {"s3_bucket_name": filter_param},
                {"shared_path": filter_param},
                {"snowflake_subscription_type": filter_param},
                {"db_authentication_type": filter_param},
                {"discovery_warehouse_type": filter_param},
                {"schema_migration_warehouse_type": filter_param},
                {"data_migration_warehouse_type": filter_param},
                {"created_by": filter_param}
            ]
        resp = list(db.link_service.find(query, {"_id": 0}))
        if not bool(resp):
            return jsonify(error.err_088), flask_api.status.HTTP_404_NOT_FOUND

        threads = []
        
        for i in range(len(resp)):
            threads.append(threading.Thread(target=link_service_status, args=(resp, i)))

        for t in threads:
            t.start()
        
        for t in threads:
            t.join()

    except Exception:
        log.error(traceback.format_exc())
        return jsonify(error.err_095), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

    log.info("END")
    send_json = {
        "status": "Success",
        "message": "Link service status fetched successfully",
        "category": "Snowflake_Migration",
        "data": resp
    }
    return response(dumps(send_json), 200)    