"""
This service contains APIs for the schema migration
"""
import datetime
import json
import logging
import sys
import traceback
import uuid
from datetime import datetime

import pandas as pd
from bson.json_util import dumps
from config import config, db, send_message
from flask import request, jsonify
from kafka import KafkaProducer
from libs.access_token import validate_access_token
from libs.util import (abcr_job_registry, abcr_job_run, abcr_job_registry_delete,
get_userdata, validate_json_schema, response, get_batch_id)
from libs import error

# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'

@app.route("/idea/services/migrationsf/schema/run", methods=["POST"])
@validate_json_schema
def schema_migration():
    """
    This API will do the schema migration
    :return: json response
    """
    log.info("START")
    data = request.get_json()
    job_id = data['job_id']

    try:
        # Validate access token
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["schema_migration"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        socket_flag = 'socket' in data
        pipeline_run_id = data['socket'] if socket_flag else None
        project_id = data['project_id']

        user_data = get_userdata(access_details, project_id)
        if not user_data:
            return jsonify(error.err_089), 400

        # Finding data and link service details
        job_register_df = db.job_registry.find_one({"job_id": job_id, "active": True,"job_type": "schema_migration",
                                                    'project_id': project_id},
                                                   {"data": 1, "source_link_service_id": 1,
                                                    "sink_link_service_id": 1, 'active': 1,
                                                    'job_name': 1, '_id': 0})

        if job_register_df is None:
            return jsonify(error.err_088), 404

        job_name = job_register_df["job_name"]
        data = job_register_df['data']
        force_create = data['force_create']

        ###################### Getting source DB details##################
        result = db.link_service.find_one(
            {"link_service_id": job_register_df['source_link_service_id'],
             "active": True})

        if result is None:
            return jsonify(error.err_096), 404

        ###################3 Getting the target DB details#################
        tgt_db_vendor = db.link_service.find_one(
            {"link_service_id": job_register_df['sink_link_service_id'],
             "active": True}, {'_id': 0, 'link_service_type': 1})

        if tgt_db_vendor is None:
            return jsonify(error.err_094), 404

        # validating for running job
        query = {"job_id": job_id}
        log.info("db.job_run.find(): query: {}".format(query))
        job_run_result = db.job_run.find(query, {"_id": 0}).sort("start_time", -1).limit(1)
        job_run_result = list(job_run_result)
        if len(job_run_result) == 1 and job_run_result[0]['status'] == "InProgress":
            resp = error.err_0109
            return jsonify(resp), 409

        discovery_id = get_batch_id(job_register_df['source_link_service_id'], project_id)
        tgt_database_server_nm = result['db_hostname']
        tgt_db_vendor = tgt_db_vendor['link_service_type'].split()[0]
        job_start = int(datetime.utcnow().timestamp())
        job_start_str = datetime.fromtimestamp(job_start).strftime(idea_date_format)
        job_run_id = str(uuid.uuid4())
        ##############JOB STATUS IN PROGRESS####################################
        job_status = "InProgress"
        job_run = {"job_run_id": job_run_id,
                   "job_id": job_id,
                   'run_by': user_data["name"],
                   "start_time": job_start,
                   "start_time_str": job_start_str,
                   "status": job_status,
                   'project_id': project_id
                   }
        ################## inserting job details in job run ####################3
        db.job_run.insert_one(job_run)
        job_detail_list = list(db.job_detail.find({"job_id": job_id}, {'_id': 0}))
        ################# Adding in job_run_detail table#########################
        for each_dict in job_detail_list:
            each_dict["job_run_id"] = job_run_id
            each_dict["start_time"] = job_start
            each_dict["start_time_str"] = job_start_str
            each_dict["force_create"] = force_create
            each_dict["status"] = "NotStarted"

        db.job_run_detail.insert_many(job_detail_list)
        server = config["kafka"]["host"]
        topic_discovery_schema = config["kafka"]["topic_discovery_schema"]
        ######################## data to be passed to the consumer ####################
        data_kafka = {
            "job_id": job_id,
            "job_run_id": job_run_id,
            "sink_link_service_id": job_register_df["sink_link_service_id"],
            "start": job_start,
            "data": job_register_df['data'],
            "tgt_db_vendor": tgt_db_vendor,
            "discovery_id": discovery_id,
            "tgt_database_server_nm": tgt_database_server_nm,
            "job_name": job_name,
            "run_by": user_data["name"],
            "type": "SCHEMA_MIGRATION",
            "user_id": user_data["user_id"],
            "socket_flag": socket_flag,
            "pipeline_run_id": pipeline_run_id,
            "pipeline_id": db.canvas_pipeline_run.find_one({"pipeline_run_id": pipeline_run_id})['pipeline_id'] if socket_flag else None
        }
        
        if socket_flag:
            send_message("sf_schema_run_job_status", {"job_id": job_id, "status": "InProgress", "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            
        try:
            producer = KafkaProducer(bootstrap_servers=server,
                                     value_serializer=lambda x: dumps(x).encode('utf-8'))
        except Exception as e_error:
            if socket_flag:
                if "database_table" in data_kafka['data']:
                    for tables in data_kafka['data']['database_table']:
                        for table in tables['tables']:
                            send_message("sf_schema_run_status", {table:{"object_type":"table","status":"Fail","database": tables['database'],"attributes":0}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
                elif "database_view" in data_kafka['data']:
                    for views in data_kafka['data']['database_view']:
                        for view in views['views']:
                            send_message("sf_schema_run_status", {view:{"object_type":"view","status":"Fail","database": views['database']}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
                elif "users" in data_kafka['data']:
                    for user in data_kafka['data']['users']:
                        send_message("sf_schema_run_status", {user:{"object_type":"user","status":"Fail"}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
                else:
                    for role in data_kafka['data']['roles']:
                        send_message("sf_schema_run_status", {role:{"object_type":"role","status":"Fail"}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
                send_message("sf_schema_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            log.error(e_error)
            status = error.err_064
            job_end = int(datetime.utcnow().timestamp())
            job_end_str = datetime.fromtimestamp(job_end).strftime(idea_date_format)
            db.job_run.update_one({'job_run_id': job_run_id},
                                  {"$set": {"status": "Fail", "end_time": job_end,
                                            "end_time_str": job_end_str}})
            db.job_run_detail.update_many({"job_run_id": job_run_id},
                                          {"$set": {"status": "Fail",
                                                    "message": "Error while producing message on job run topic",
                                                    "end_time": job_end,
                                                    "end_time_str": job_end_str}})
            return jsonify(status), 500

        if config["ABCR"]["flag"] == "Y":
            configuration = {
                "endPoint": {"url": "/idea/services/migrationsf/schema/run", "method": "POST"},
                "params": {"jobId": job_id}}
            abcr_status = abcr_job_run(configuration, "", "",
                                       job_id, job_run_id, job_name,
                                       "migrating schema from teradata to snowflake",
                                       "", user_data["name"],
                                       job_start, "InProgress", config['ABCR']['schema'], "")
            if abcr_status == "Fail":
                status = error.err_064
                job_end = int(datetime.utcnow().timestamp())
                job_end_str = datetime.fromtimestamp(job_end).strftime(idea_date_format)
                db.job_run.update_one({'job_run_id': job_run_id},
                                      {"$set": {"status": "Fail", "end_time": job_end,
                                                "end_time_str": job_end_str}})
                db.job_run_detail.update_many({"job_run_id": job_run_id},
                                              {"$set": {"status": "Fail",
                                                        "message": "Error while producing message on job run topic",
                                                        "end_time": job_end,
                                                        "end_time_str": job_end_str}})
                return jsonify(status), 500
        producer.send(topic_discovery_schema, value=data_kafka)
        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "data": {"job_id": job_id,
                         "job_run_id": job_run_id},
                "message": "Schema migration job in progress"
                }
    except Exception as e_error:
        if socket_flag:
            if "database_table" in data_kafka['data']:
                for tables in data_kafka['data']['database_table']:
                    for table in tables['tables']:
                        send_message("sf_schema_run_status", {table:{"object_type":"table","status":"Fail","database": tables['database'],"attributes":0}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            elif "database_view" in data_kafka['data']:
                for views in data_kafka['data']['database_view']:
                    for view in views['views']:
                        send_message("sf_schema_run_status", {view:{"object_type":"view","status":"Fail","database": views['database']}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            elif "users" in data_kafka['data']:
                for user in data_kafka['data']['users']:
                    send_message("sf_schema_run_status", {user:{"object_type":"user","status":"Fail"}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            else:
                for role in data_kafka['data']['roles']:
                    send_message("sf_schema_run_status", {role:{"object_type":"role","status":"Fail"}, "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
            send_message("sf_schema_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": data_kafka['pipeline_id'], "pipeline_run_id": pipeline_run_id}, data_kafka['user_id'])
        log.info(e_error)
        log.error(traceback.format_exc())
        status = error.err_095
        job_end = int(datetime.utcnow().timestamp())
        job_end_str = datetime.fromtimestamp(job_end).strftime(idea_date_format)
        db.job_run.update_one({'job_run_id': job_run_id},
                              {"$set": {"status": "Fail", "end_time": job_end,
                                        "end_time_str": job_end_str}})

        return jsonify(status), 500

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/schema/job-register", methods=["GET"])
@validate_json_schema
def get_schema_migration_job():
    """
    This API will list down the schema migration jobs
    :return: json response
    """
    log.info("START")
    data = request.args
    try:
        # Validate access token
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["schema_migration"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        user_data = get_userdata(access_details, data['project_id'])
        if not user_data:
            return jsonify(error.err_089), 400

        query = {'job_type': 'schema_migration', 'active': True,'project_id': data['project_id']}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"job_name": filter_param},
                {"data.database_table.database": filter_param},
                {"data.database_table.tables": filter_param},
                {"data.database_view.database": filter_param},
                {"data.database_view.views": filter_param},
                {"data.roles": filter_param},
                {"data.users": filter_param},
                {"created_by": filter_param}
            ]

        info_df = list(
            db.job_registry.find(query,
                                 {'created_at_str': 0, '_id': 0, 'project_id': 0, 'active': 0}).sort([("created_at", -1)]))
        if len(info_df) == 0:
            return jsonify(error.err_088), 404
        for job in range(len(info_df)):
            source_link_service_name = db.link_service.find_one({"link_service_id": info_df[job]['source_link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            sink_link_service_name = db.link_service.find_one({"link_service_id": info_df[job]['sink_link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            info_df[job]['source_link_service_name'] = source_link_service_name['link_service_name']
            info_df[job]['sink_link_service_name'] = sink_link_service_name['link_service_name']
            info_df[job]['project_name'] = user_data['project_name']
        for item in info_df:
            if 'data' in item and item["data"] is not None:
                item["data"] = str(item["data"])
                item["data"] = json.loads(
                    item["data"].replace('True', 'true').replace('False', 'false').replace('\'',
                                                                                           '"'))

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), 500

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Fetched schema migration job details successfully",
                    "data": info_df}), 200


@app.route("/idea/services/migrationsf/schema/job-register", methods=["POST"])
@validate_json_schema
def create_schema_migration_job():
    """
    This API will insert job details in job master table
    """
    try:
        # Validate access token
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["schema_migration"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        
        data = request.get_json()

        user_data = get_userdata(access_details, data['project_id'])
        if not user_data:
            return jsonify(error.err_089), 400

        # Validate duplicate name
        job_name = data['job_name']
        job_exist = db.job_registry.find_one({'job_name': job_name, "active": True, "project_id": data["project_id"]})
        if bool(job_exist):
            status = error.err_061
            return jsonify(status), 409

        # Validate source_link_service_id & sink_link_service_id
        source_link_service_id = db.link_service.find_one(
            {"link_service_id": data['source_link_service_id'],
             "active": True})
        if source_link_service_id is None:
            return jsonify(error.err_096), 404
        sink_link_service_id = db.link_service.find_one(
            {"link_service_id": data['sink_link_service_id'],
             "active": True})
        if sink_link_service_id is None:
            return jsonify(error.err_094), 404

        project_id = data['project_id']
        project_name = user_data['project_name']

        # Insert into job_registry
        job_id = str(uuid.uuid4())
        created_at = int(datetime.utcnow().timestamp())
        created_at_str = datetime.fromtimestamp(created_at).strftime(idea_date_format)
        job_register_df = {'job_id': job_id,
                           'job_type': "schema_migration",
                           'job_name': data['job_name'],
                           'source_link_service_id': data['source_link_service_id'],
                           'sink_link_service_id': data['sink_link_service_id'],
                           'data': data['data'],
                           'active': True,
                           'created_by': user_data["name"],
                           'project_id': project_id,
                           'created_at': created_at,
                           'created_at_str': created_at_str
                           }

        if config["ABCR"]["flag"] == "Y":
            configuration = {
                "endPoint": {"url": "/idea/services/migrationsf/schema/run", "method": "POST"},
                "params": {"jobId": job_id}
            }
            parameters = {
                "jobType": "schema_migration",
                "job_name": data['job_name'],
                "source": {
                    "type": source_link_service_id['link_service_type'],
                    "linkServiceID": data["source_link_service_id"],
                    "bowID": data["source_link_service_id"]
                },
                "destination": {
                    "type": sink_link_service_id["link_service_type"],
                    "linkServiceID": data["sink_link_service_id"],
                    "bowID": data["sink_link_service_id"]
                },
                "data": data["data"],
            }

            job_status = abcr_job_registry(job_id, True, "Other", configuration,
                                           parameters,
                                            created_at,
                                           config['ABCR']['schema'], job_name,
                                           "MigrationSF-Schema Migration",
                                           " ", " ", " ", " ",
                                           project_id, user_data["name"], " ", " ", project_name)
            if job_status == "Fail":
                resp = {"status": "Fail",
                        "category": "Snowflake_Migration",
                        "error_code": "IDEA_ERR_063",
                        "message": "Error while producing message on job register topic",
                        "data": ""}
                return jsonify(resp), 500
        # insert into job_registry
        log.info("db.job_registry.insert(): data: {}".format(job_register_df))
        db.job_registry.insert_one(job_register_df)
        # insert into job_detail
        info_df = pd.json_normalize(data["data"])
        for i in info_df.index:
            try:
                database_table = info_df["database_table"][i]
            except KeyError:
                database_table = []
            for table in database_table:
                length = len(table['tables'])
                item_id_list = []
                for _ in range(0, length):
                    item_id_list.append(str(uuid.uuid4()))
                table_df = pd.DataFrame(
                    zip([job_id] * length, item_id_list, ['table'] * length, table['tables'],
                        [table['database']] * length),
                    columns=['job_id', 'item_id', 'object_type', 'object_name', 'object_parent'])
                db.job_detail.insert_many(table_df.T.to_dict().values())

            try:
                database_view = info_df["database_view"][i]
            except KeyError:
                database_view = []

            for view in database_view:
                length = len(view['views'])
                item_id_list = []
                for i_id in range(0, length):
                    item_id_list.append(str(uuid.uuid4()))
                view_df = pd.DataFrame(
                    zip([job_id] * length, item_id_list, ['view'] * length, view['views'],
                        [view['database']] * length),
                    columns=['job_id', 'item_id', 'object_type', 'object_name', 'object_parent'])
                db.job_detail.insert_many(view_df.T.to_dict().values())

            item_id_list = []
            if "roles" in info_df:
                roles = info_df["roles"][i]
                length = len(roles)
                for i_id in range(0, length):
                    item_id_list.append(str(uuid.uuid4()))
                role_df = pd.DataFrame(
                    zip([job_id] * length, item_id_list, ['role'] * length, roles),
                    columns=['job_id', 'item_id', 'object_type', 'object_name'])
                db.job_detail.insert_many(role_df.T.to_dict().values())

            item_id_list = []
            if "users" in info_df:
                users = info_df["users"][i]
                length = len(users)
                for _ in range(0, length):
                    item_id_list.append(str(uuid.uuid4()))
                user_df = pd.DataFrame(
                    zip([job_id] * length, item_id_list, ['user'] * length, users),
                    columns=['job_id', 'item_id', 'object_type', 'object_name'])
                db.job_detail.insert_many(user_df.T.to_dict().values())

        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Job registered successfully",
                "data": {"job_id": job_id}
                }

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), 500

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/schema/job-register", methods=["DELETE"])
@validate_json_schema
def delete_schema_migration_job():
    """
    This API will delete job record from job master table
    :return: json response
    """
    log.info("START")

    try:
        # Validate access token
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["schema_migration"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.args

        user_data = get_userdata(access_details, data['project_id'])
        if not user_data:
            return jsonify(error.err_089), 400

        job_id = data['job_id']
        job_register_df = db.job_registry.find_one(
            {"job_id": job_id, 'project_id': data['project_id']},
            {'_id': 0, 'execution_schedule': 1,
             'created_at': 1, 'created_at_str': 1,
             'active': 1, 'job_name': 1})

        if not bool(job_register_df):
            return jsonify(error.err_088), 404
        if not job_register_df['active']:
            return jsonify(error.err_085), 404

        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry_delete(job_id, False)
            if job_status == "Fail":
                resp = error.err_063
                return jsonify(resp), 500

        db.job_registry.update_one({"job_id": job_id},{'$set': {'active': False}})

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), 500

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Record deleted successfully",
                    "data": ""}), 200


@app.route("/idea/services/migrationsf/schema/status", methods=["POST"])
@validate_json_schema
def schema_migration_status():
    log.info("START")

    try:
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["schema_migration"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.get_json()

        user_data = get_userdata(access_details, data['project_id'])
        if not user_data:
            return jsonify(error.err_089), 400

        query = {'job_run_id': data["job_run_id"], 'project_id': data['project_id']}

        job_run_info = db.job_run.find_one(query, {"start_time_str": 0,
                                                   "end_time_str": 0, "_id": 0, 'project_id':0})

        if job_run_info is None:
            return jsonify(error.err_088), 404
        if db.job_registry.find_one({"job_id": job_run_info['job_id'],
                                     "job_type": "schema_migration", "active": True}) is None:
            return jsonify(error.err_088), 404

        job_run_detail = list(
            db.job_run_detail.find({'job_run_id': data["job_run_id"]}, {"start_time_str": 0,
                                                                        "end_time_str": 0,
                                                                        "_id": 0}))

    except Exception:
        log.error(traceback.format_exc())
        status = error.err_095
        return jsonify(status), 500
    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Fetched schema migration status successfully",
                    "data": {"job_run": job_run_info, "job_run_detail": job_run_detail}
                    }), 200
