"""
This service contains APIs for canvas pipelines
"""

import uuid
import json
import logging
import requests
import threading
import concurrent.futures
from datetime import datetime
from bson.json_util import dumps
from flask import request, jsonify
from config import config, db, db_client, send_message
from libs import error
from libs.access_token import validate_access_token
from libs.util import (validate_json_schema,get_userdata, response)

# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
abcr_flag = config['canvas_abcr']['flag'] == "Y"
abcr_db = db_client[config['canvas_abcr']['database']]
abcr_category = config['canvas_abcr']['category']

def update_abcr(pipeline_run_id, end_time, end_time_str, status):
    if abcr_flag:
        pipeline_run = db.canvas_pipeline_run.find_one({"pipeline_run_id": pipeline_run_id}, {"_id": 0, "logs": 1, "dashboards": 1, "grids": 1})
        abcr_db.canvas_pipeline_run.update_one({"pipelineRunID": pipeline_run_id}, {"$set": {"endTimestamp": end_time, "end": end_time_str, "status": status, "executionLog.logs": pipeline_run['logs'], "output.dashboards": pipeline_run['dashboards']}})
        if status == "Success":
            abcr_db.canvas_pipeline_run.update_one({"pipelineRunID": pipeline_run_id}, {"$set": {"output.grids": pipeline_run['grids']}})


@app.route("/idea/services/migrationsf/pipeline/templates", methods=["GET"])
def pipeline_templates():
    """
    This API will list down the canvas templates
    """
    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        result = ["Complexity Analyzer", "Data Migration", "ETL Migration", "Schema Migration"]

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Get pipeline templates executed successfully",
                    "data": result}), 200


@app.route("/idea/services/migrationsf/pipeline/template", methods=["GET"])
@validate_json_schema
def pipeline_template():
    """
    This API will list down the canvas template
    """
    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.args
        result = db.canvas_templates.find_one({"pipeline_template": data['pipeline_template']}, {"_id": 0})

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Get template executed successfully",
                    "data": result}), 200


@app.route("/idea/services/migrationsf/pipeline/register", methods=["POST"])
def create_pipeline():
    """
    This API will create a canvas pipeline
    """
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.get_json()
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        pipeline_name = data["pipeline_name"].strip()
        previous_pipeline = db.canvas_pipeline.find_one({"pipeline_name":{'$regex': "^"+pipeline_name+"$", '$options': 'i'},"project_id": project_id,"active":True})
        if bool(previous_pipeline):
            return response(dumps(error.err_097), 409)

        pipeline_id = str(uuid.uuid4())
        created_at = int(datetime.utcnow().timestamp())
        created_at_str = str(datetime.fromtimestamp(created_at).strftime(idea_date_format))

        # Updating canvas_pipeline metadata
        pipeline_df = {
            "pipeline_name": pipeline_name,
            "project_id": project_id,
            "elements": data.get("elements", []),
            "data": data.get("data", []),
            "created_by": user_data["name"],
            "created_at": created_at,
            "created_at_str": created_at_str,
            "pipeline_id": pipeline_id,
            "modified_at": created_at,
            "modified_at_str": created_at_str,
            "modified_by": user_data["name"],
            "runs": 0,
            "active": True
        }
        db.canvas_pipeline.insert_one(pipeline_df)

        if abcr_flag:
            abcr_data = {
                "pipelineRegisterID": pipeline_id,
                "active": True,
                "category": abcr_category,
                "config": {
                    "endpoint": {
                        "url": "/idea/services/migrationsf/pipeline/run",
                        "method": "POST"
                    },
                    "params": {
                        "pipeline_id": pipeline_id,
                        "data": [],
                        "project_id": project_id
                    }
                },
                "createdBy": user_data["name"],
                "createdDate": created_at_str,
                "createdDateTimestamp": created_at,
                "pipelineName": pipeline_name,
                "modificationDate": created_at_str,
                "modificationDateTimestamp": created_at,
                "modifiedBy": user_data["name"],
                "parameters": {
                    "data": pipeline_df['data'],
                    "elements": pipeline_df['elements'],
                    "runs": 0
                },
                "projectID": project_id
            }
            abcr_db.canvas_pipeline.insert_one(abcr_data)

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Pipeline registered successfully",
                "data": {"pipeline_id": pipeline_id}}), 200


@app.route("/idea/services/migrationsf/pipeline/register", methods=["GET"])
@validate_json_schema
def get_pipeline():
    """
    This API will list down the canvas pipelines
    """
    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)

        result = list(db.canvas_pipeline.find({"project_id": project_id, "active": True}, {"_id": 0, "project_id": 0, "created_at_str": 0, "modified_at_str": 0, "active": 0}).sort([("created_at", 1)]))
        for i in range(len(result)):
            result[i]['status'] = "Created"
            result[i]['in_progress'] = False
            latest_run = list(db.canvas_pipeline_run.find({"pipeline_id": result[i]['pipeline_id']}, {"_id": 0, "status": 1, "dashboards": 1, "logs": 1, "grids": 1}).sort([("start_time", -1)]).limit(1))
            if bool(latest_run):
                result[i]['status'] = latest_run[0]['status']
                result[i]['dashboards'] = latest_run[0]['dashboards']
                result[i]['logs'] = latest_run[0]['logs']
                result[i]['in_progress'] = latest_run[0]['status'] == "InProgress"
                if "grids" in latest_run[0]:
                    result[i]['grids'] = latest_run[0]['grids']
        if result == []:
            return response(dumps(error.err_099), 404)

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Get pipeline has been successfully executed",
                    "data": result}), 200


@app.route("/idea/services/migrationsf/pipeline/register", methods=["PUT"])
def update_pipeline():
    """
    This API will update details in canavs pipeline
    """
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.get_json()
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)

        pipeline_id = data["pipeline_id"]
        if not bool(db.canvas_pipeline.find_one({"pipeline_id": pipeline_id, "project_id": project_id, "active": True})):
            return response(dumps(error.err_099), 404)

        if bool(db.canvas_pipeline_run.find_one({"pipeline_id": pipeline_id, "status": "InProgress"})):
            return response(dumps(error.err_107), 404)

        modified_at = int(datetime.utcnow().timestamp())
        modified_at_str = str(datetime.fromtimestamp(modified_at).strftime(idea_date_format))
        db.canvas_pipeline.update_one({"pipeline_id": pipeline_id},{"$set": {"elements": data["elements"], "data": data['data'], "modified_at": modified_at, "modified_at_str": modified_at_str, "modified_by": user_data['name']}})

        if abcr_flag:
            abcr_db.canvas_pipeline.update_one({"pipelineRegisterID": pipeline_id}, {"$set": {"parameters.elements": data["elements"], "parameters.data": data['data'], "modificationDateTimestamp": modified_at, "modificationDate": modified_at_str, "modifiedBy": user_data['name']}})

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Pipeline updated successfully"}), 200


@app.route("/idea/services/migrationsf/pipeline/register", methods=["DELETE"])
@validate_json_schema
def delete_pipeline():
    """
    This API will delete canvas pipeline
    """
    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        pipeline_id = data["pipeline_id"]
        if not bool(db.canvas_pipeline.find_one({"pipeline_id": pipeline_id, "project_id": project_id, "active": True})):
            return response(dumps(error.err_099), 404)

        if bool(db.canvas_pipeline_run.find_one({"pipeline_id": pipeline_id, "status": "InProgress"})):
            return response(dumps(error.err_108), 404)

        pipeline_jobs = db.job_registry.find({"pipeline_id": pipeline_id}, {"_id": 0, "job_id": 1})
        if bool(pipeline_jobs):
            pipeline_jobs = [job['job_id'] for job in pipeline_jobs]

        db.canvas_pipeline.update_one({"pipeline_id": pipeline_id}, {'$set': {'active': False}})
        db.canvas_pipeline_run.update_many({"pipeline_id": pipeline_id}, {'$set': {'active': False}})
        db.job_registry.update_many({"job_id": {"$in": pipeline_jobs}}, {"$set": {"active": False}})
        abcr_db.job_register.update_many({"jobRegisterID": {"$in": pipeline_jobs}}, {"$set": {"active": False}})

        if abcr_flag:
            abcr_db.canvas_pipeline.update_one({"pipelineRegisterID": pipeline_id}, {"$set": {"active": False}})
            abcr_db.canvas_pipeline_run.update_many({"pipelineRegisterID": pipeline_id}, {"$set": {"active": False}})

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Pipeline deleted successfully",
                    "data": ""}), 200


@app.route("/idea/services/migrationsf/pipeline/monitor", methods=["GET"])
@validate_json_schema
def pipeline_monitor():
    """
    This API will return canavs pipeline monitor
    """
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)

        pipeline_id = data["pipeline_id"]
        pipeline = db.canvas_pipeline.find_one({"pipeline_id": pipeline_id, "active": True})
        if not bool(pipeline):
            return response(dumps(error.err_099), 404)
        
        result = {
            "run_count": 0,
            "runs": [],
        }
        runs = list(db.canvas_pipeline_run.find({"pipeline_id": pipeline_id}, {"_id": 0, "end_time": 1, "pipeline_id": 1, "pipeline_run_id": 1, "pipeline_run_name": 1, "run_by": 1, "start_time": 1, "status": 1, "snowflake_url": 1}))
        if runs != []:
            result['run_count'] = pipeline['runs']
            result['runs'] = runs

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Get pipeline monitor executed successfully",
                    "data": result}), 200


@app.route("/idea/services/migrationsf/pipeline/logs", methods=["GET"])
@validate_json_schema
def get_logs():
    """
    This API will list down the canvas pipelines logs
    """
    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)

        if "pipeline_id" in data:
            result = list(db.canvas_pipeline_run.find({"pipeline_id": data['pipeline_id'], "project_id": project_id, "active": True}, {"_id": 0, "status": 1, "dashboards": 1, "logs": 1, "grids": 1}).sort([("start_time", -1)]).limit(1))
            if bool(result):
                result = result[0]
        else:
            result = db.canvas_pipeline_run.find_one({"pipeline_run_id": data['pipeline_run_id'], "project_id": project_id, "active": True}, {"_id": 0, "status": 1, "dashboards": 1, "logs": 1, "grids": 1})
        if not bool(result):
            return response(dumps(error.err_099), 404)

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Get pipeline logs executed successfully",
                    "data": result}), 200

            
@app.route("/idea/services/migrationsf/pipeline/stats", methods=["GET"])
@validate_json_schema
def pipeline_stats():
    """
    This API will fetch pipeline details for a project
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return jsonify(error.err_051), 401

        data = request.args
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return jsonify(error.err_089), 400

        result = {
            "pipeline": 0,
            "run": 0,
            "success": 0,
            "fail": 0,
            "progress": 0
        }

        active_pipelines = list(db.canvas_pipeline.find({"project_id": project_id, "active": True}, {"_id": 0, "pipeline_id": 1}))
        if bool(active_pipelines):
            active_pipelines = [pipeline['pipeline_id'] for pipeline in active_pipelines]
            result['pipeline'] = len(active_pipelines)
            result['run'] = db.canvas_pipeline_run.count_documents({"pipeline_id": {"$in": active_pipelines}})
            success = db.canvas_pipeline_run.count_documents({"pipeline_id": {"$in": active_pipelines}, "status": "Success"})
            fail = db.canvas_pipeline_run.count_documents({"pipeline_id": {"$in": active_pipelines}, "status": "Fail"})
            progress = db.canvas_pipeline_run.count_documents({"pipeline_id": {"$in": active_pipelines}, "status": "InProgress"})
            if result['run']:
                result['success'] = round((success/result['run'])*100, 2)
                result['fail'] = round((fail/result['run'])*100, 2)
                result['progress'] = round((progress/result['run'])*100, 2)

    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({
        "status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Pipeline stats fetched successfully",
        "data": result
    }), 200


@app.route("/idea/services/migrationsf/pipeline/run", methods=["POST"])
@validate_json_schema
def run_pipeline():
    """
    This API will create a canvas pipeline
    """
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'), permissions=["canvas_pipeline"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        data = request.get_json()
        project_id = data['project_id']

        # Project validation
        user_data = get_userdata(access_details, project_id)
        if user_data == False:
            return response(dumps(error.err_089), 400)

        start_time = int(datetime.utcnow().timestamp())
        start_time_str = str(datetime.fromtimestamp(start_time).strftime(idea_date_format))
        pipeline_run_id = str(uuid.uuid4())
        user_id = user_data['user_id']
        pipeline_id = data['pipeline_id']

        pipeline = db.canvas_pipeline.find_one({"pipeline_id": pipeline_id, "active": True})
        if not bool(pipeline):
            return response(dumps(error.err_099), 404)

        if bool(db.canvas_pipeline_run.find_one({"pipeline_id": pipeline_id, "status": "InProgress"})):
            return response(dumps(error.err_107), 404)            

        run_count = pipeline['runs'] + 1
        db.canvas_pipeline.update_one({"pipeline_id": pipeline_id}, {"$set": {"runs": run_count}})
        snowflake_url = db.link_service.find_one({"link_service_id": pipeline['data'][0]['PipelineLinkServiceIDs']['sink_link_service_id']}, {"db_hostname": 1})

        if abcr_flag:
            abcr_db.canvas_pipeline.update_one({"pipelineRegisterID": pipeline_id}, {"$set": {"parameters.runs": run_count}})

        pipeline_df = {
            "pipeline_id": pipeline_id,
            "project_id": project_id,
            "pipeline_run_id": pipeline_run_id,
            "pipeline_run_name": pipeline['pipeline_name'] + "_" + str(run_count),
            "start_time": start_time,
            "start_time_str": start_time_str,
            "run_by": user_data['name'],
            "status": "InProgress",
            "logs": [],
            "dashboards": {},
            "active": True,
            "snowflake_url": snowflake_url['db_hostname'] if snowflake_url else None
        }
        db.canvas_pipeline_run.insert_one(pipeline_df)

        if abcr_flag:
            abcr_data = {
                "category": abcr_category,
                "runBy": user_data['name'],
                "status": "InProgress",
                "executionLog": {
                    "logs": []
                },
                "output": {
                    "dashboards": {},
                    "grids": {
                        "complexity_grid": [],
                        "data_grid": [],
                        "etl_grid": [],
                        "schema_grid": []
                    }
                },
                "start": start_time_str,
                "startTimestamp": start_time,
                "pipelineRegisterID": pipeline_id,
                "pipelineRunID": pipeline_run_id,
                "pipelineName": pipeline['pipeline_name'],
                "pipelineRunName": pipeline_df['pipeline_run_name'],
                "projectID": project_id,
                "active": True
            }
            abcr_db.canvas_pipeline_run.insert_one(abcr_data)

        if not bool(data['data']):
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = str(datetime.fromtimestamp(end_time).strftime(idea_date_format))
            db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"end_time": end_time, "end_time_str": end_time_str, "status": "Fail"}})
            update_abcr(pipeline_run_id, end_time, end_time_str, "Fail")
            return response(dumps(error.err_074), 400)

        send_message("socket_connection", {"status": "Socket connection established", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        send_message("sf_global_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "InProgress", "pipeline_run_id": pipeline_run_id}, user_id)
        send_message("sf_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "InProgress", "pipeline_run_id": pipeline_run_id}, user_id)

        complexity_files = 0
        data_tables = 0
        etl_files = 0
        schema_objects = 0
        snowsql = 0
        pyexec = 0

        for job in data['data']:
            job_data = db.job_registry.find_one({"job_id": job['job_id']}, {"_id": 0})
            sub_data = job_data['data']
            if job['job_type'] == "complexity_analyzer":
                complexity_files += len(sub_data['files'])
            elif job['job_type'] == "data_migration":
                for tables in sub_data['database_details']:
                    data_tables += len(tables['tables'])
            elif job['job_type'] == "etl_snowflake":
                etl_files += len(sub_data['files'])
                if job['file_type'] == "SnowSQL":
                    snowsql += len(sub_data['files'])
                else:
                    pyexec += len(sub_data['files'])
            else:
                if "database_table" in sub_data:
                    for tables in sub_data['database_table']:
                        schema_objects += len(tables['tables'])
                elif "database_view" in sub_data:
                    for view in sub_data['database_view']:
                        schema_objects += len(view['views'])
                elif "users" in sub_data:
                    schema_objects += len(sub_data['users'])
                else:
                    schema_objects += len(sub_data['roles'])

        if complexity_files:
            db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"dashboards.sf_complexity_run_count_ui": {"total": complexity_files}}})
            send_message("sf_complexity_run_count", {"total": complexity_files, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        if data_tables:
            db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"dashboards.sf_data_run_count_ui": {"total": data_tables}}})
            send_message("sf_data_run_count", {"total": data_tables, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        if etl_files:
            db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"dashboards.sf_etl_run_count_ui": {"total": etl_files, "snowsql": snowsql, "pyexec": pyexec}}})
            send_message("sf_etl_run_count", {"total": etl_files, "snowsql": snowsql, "pyexec": pyexec, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        if schema_objects:
            db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"dashboards.sf_schema_run_count_ui": {"total": schema_objects}}})
            send_message("sf_schema_run_count", {"total": schema_objects, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)

        headers = {'Authorization': str(request.headers.get('Authorization')), "Content-Type": "application/json"}        
        for job in data['data']:
            threading.Thread(target=execute_job, args=(headers, job, project_id, True, pipeline_id, pipeline_run_id)).start()

        threading.Thread(target=update_pipeline_status, args=(pipeline_id, pipeline_run_id, data['data'], user_id)).start()

    except Exception as e_error:
        send_message("sf_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Fail", "pipeline_run_id": pipeline_run_id}, user_id)
        send_message("sf_global_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Fail", "pipeline_run_id": pipeline_run_id}, user_id)
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = str(datetime.fromtimestamp(end_time).strftime(idea_date_format))
        db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"end_time": end_time, "end_time_str": end_time_str, "status": "Fail"}})
        update_abcr(pipeline_run_id, end_time, end_time_str, "Fail")
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "Pipeline is in progress",
                "data": {"pipeline_run_id": pipeline_run_id}}), 200


def prepare_grids(jobs):

    complexity_grid = []
    data_grid = []
    etl_grid = []
    schema_grid = []
    for job in jobs:
        job_data = db.job_registry.find_one({"job_id": job['job_id']}, {"_id": 0})
        run_data = list(db.job_run_detail.find({"job_id": job['job_id']}, {"_id": 0}))
        if job['job_type'] == "complexity_analyzer":
            rule = job_data['rule']
            for file in run_data:
                complex_row = {
                    "file": file['object_name'],
                    "rule": rule,
                    "status": file['status'],
                    "complexity": db.idea_complexity_analyzer_summary.find_one({"job_run_id": file['job_run_id'], "script_name": file['object_name']+".btq"})['complexity']
                }
                complexity_grid.append(complex_row)
        elif job['job_type'] == "data_migration":
            for data_table in run_data:
                data_row = {
                    "database": data_table['object_parent'],
                    "table": data_table['object_name'],
                    "records": data_table.get('noofrows_written_sf', 0),
                    "load_type": data_table['load_type'],
                    "data_status": data_table['status_sf']
                }
                schema_flag = False
                if "data" in job:
                    for schema_job in job['data']:
                        schema_run = db.job_run_detail.find_one({"job_id":schema_job['job_id'],"object_parent":data_table['object_parent'],"object_name":data_table['object_name']},{"_id":0})
                        if bool(schema_run):
                            data_row['schema'] = "Default Schema"
                            data_row['force_create'] = "Yes" if schema_run['force_create'] else "No"
                            data_row['schema_status'] = schema_run['status']
                            schema_flag = True
                            break
                    if not schema_flag:
                            data_row['schema'] = "N/A"
                            data_row['force_create'] = "N/A"
                            data_row['schema_status'] = "N/A"
                else:
                    data_row['schema'] = "N/A"
                    data_row['force_create'] = "N/A"
                    data_row['schema_status'] = "N/A"
                data_grid.append(data_row)
        elif job['job_type'] == "etl_snowflake":
            project_id = job_data['project_id']
            file_type = job['file_type']
            for file in run_data:
                etl_row = {
                    "file": file['input_file'],
                    "file_type": file_type,
                    "status": file['status'],
                    "download": {
                        "job_run_id": file['job_run_id'],
                        "file_name": file['snowflake_file'] if file_type == "SnowSQL" else file['snowflake_python_exec'],
                        "project_id": project_id
                    }
                }
                etl_grid.append(etl_row)
        else:
            for object in run_data:
                schema_row = {
                    "database": object.get("object_parent", "N/A"),
                    "object_name": object['object_name'],
                    "object_type": object['object_type'].capitalize(),
                    "force_create": "Yes" if object['force_create'] else "No",
                    "status": object['status']
                }
                schema_grid.append(schema_row)
    
    grids = {
        "complexity_grid": complexity_grid,
        "data_grid": data_grid,
        "etl_grid": etl_grid,
        "schema_grid": schema_grid
    }
    return grids


def update_pipeline_status(pipeline_id, pipeline_run_id, jobs, user_id):
    try:
        for job in jobs:
            while True:
                try:
                    job_status = db.job_run.find_one({"job_id": job['job_id']}, {"_id": 0, "status": 1})['status']
                    if job_status in ['Success', 'Fail']:
                        break
                except:
                    pass

        grids = prepare_grids(jobs)
        send_message("sf_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Success", "grids": grids, "pipeline_run_id": pipeline_run_id}, user_id)
        send_message("sf_global_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Success", "pipeline_run_id": pipeline_run_id}, user_id)
        
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = str(datetime.fromtimestamp(end_time).strftime(idea_date_format))
        db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"end_time": end_time, "end_time_str": end_time_str, "status": "Success", "grids": grids}})
        update_abcr(pipeline_run_id, end_time, end_time_str, "Success")
    except Exception as e_error:
        send_message("sf_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Fail", "pipeline_run_id": pipeline_run_id}, user_id)
        send_message("sf_global_pipeline_run_status", {"pipeline_id": pipeline_id, "status": "Fail", "pipeline_run_id": pipeline_run_id}, user_id)
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = str(datetime.fromtimestamp(end_time).strftime(idea_date_format))
        db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$set": {"end_time": end_time, "end_time_str": end_time_str, "status": "Fail"}})
        update_abcr(pipeline_run_id, end_time, end_time_str, "Fail")
        log.error(e_error)


def execute_job(headers, job, project_id, socket_flag, pipeline_id, pipeline_run_id):
    
    base_url = config['url']['base']
    urls = {
        "complexity_analyzer": "/idea/services/migrationsf/complexityanalyzer/run",
        "data_migration": "/idea/services/migrationsf/data/run",
        "etl_snowflake": "/idea/services/migrationsf/etl_td_snowflake/run",
        "schema_migration": "/idea/services/migrationsf/schema/run"
    }
    sequence = 0
    payload = {
        "job_id": job['job_id'],
        "project_id": project_id
    }
    if socket_flag:
        payload['socket'] = pipeline_run_id
    payload = json.dumps(payload)
    job_type = job['job_type']
    db.job_registry.update_one({"job_id": job['job_id']}, {"$set": {"pipeline_id": pipeline_id}})
    if 'data' not in job:
        requests.request("POST", base_url+urls[job_type], headers=headers, data=payload)
    else:
        with concurrent.futures.ThreadPoolExecutor() as executor:
            for sub_job in job['data']:
                sub_sequence = 1 + executor.submit(execute_job, headers, sub_job, project_id, False, pipeline_id, pipeline_run_id).result()
                sequence = max(sequence, sub_sequence)
            for sub_job in job['data']:
                while True:
                    try:
                        job_status = db.job_run.find_one({"job_id": sub_job['job_id']}, {"_id": 0, "status": 1})['status']
                        if job_status in ['Success', 'Fail']:
                            break
                    except:
                        pass
            requests.request("POST", base_url+urls[job['job_type']], headers=headers, data=payload)
    
    logs = db.job_registry.find_one({"job_id": job['job_id']}, {"_id": 0, "job_id": 1, "job_name": 1, "data": 1, 'load_type': 1, 'data_migration_option': 1, 'source_link_service_id': 1, 'sink_link_service_id': 1, 'link_service_id': 1})
    logs['job_type'] = job_type
    if 'link_service_id' in logs:
        link_service = db.link_service.find_one({"link_service_id": logs['link_service_id']}, {"_id": 0})
        logs['source_name'] = link_service['link_service_name']
        logs['source_host'] = link_service['db_hostname']
        logs['source_user'] = link_service['db_user']
        logs.pop('link_service_id')
    else:
        source_link_service = db.link_service.find_one({"link_service_id": logs['source_link_service_id']}, {"_id": 0})
        target_link_service = db.link_service.find_one({"link_service_id": logs['sink_link_service_id']}, {"_id": 0})
        logs['source_name'] = source_link_service['link_service_name']
        logs['source_host'] = source_link_service['db_hostname']
        logs['source_user'] = source_link_service['db_user']
        logs['target_name'] = target_link_service['link_service_name']
        logs['target_host'] = target_link_service['db_hostname']
        logs['target_user'] = target_link_service['db_user']
        logs.pop('source_link_service_id')
        logs.pop('sink_link_service_id')
    while True:
        try:
            job_status = db.job_run.find_one({"job_id": job['job_id']}, {"_id": 0, "status": 1})['status']
            if job_status in ['Success', 'Fail']:
                break
        except:
            pass
    logs['status'] = job_status
    db.canvas_pipeline_run.update_one({"pipeline_run_id": pipeline_run_id}, {"$push": {"logs." + str(sequence): logs}})
    return sequence