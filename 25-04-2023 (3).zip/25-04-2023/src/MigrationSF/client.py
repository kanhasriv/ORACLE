import boto3
import configparser
from socketio import Client

config = configparser.ConfigParser()
config.read("config.ini")
session = boto3.session.Session()
sm_client = session.client(
    service_name='secretsmanager',
    region_name=config['aws']['region_name'],
    aws_access_key_id="AKIAWSJ3O4ZMD22ZOZLW",
    aws_secret_access_key="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"
)

#socket = Client(logger=True, engineio_logger=True)
#socket.connect(sm_client.get_secret_value(SecretId=config["aws_secrets"]["socket_server"])["SecretString"])

def send_message(event, data, room):
    try:
        data = {
            "data": data,
            "room": room
        }
        # socket.emit(event, data)
    except:
        pass
