import re

dict_re = {
    "INSERT": r"(?i)(insert\s+into\s+(\${\w+}\.){0,1}\w+\s*)\(([^\)]+)\)",
    "COLUMNS": r"(\w+\.)"
}

string = """
INSERT INTO {{work_db}}.n_LO_EML_ADS2( EM_ADS, ID_PRTY, vs, ve, _variant_seqn ,y.INSTNC_ST_NM ,y.SRC_SYS_NM ,y.ETL_PROC_NM ,y.ETL_BTCH_ID ,y.UPDT_DTS )
INSERT INTO n_LO_EML_ADS2( EM_ADS, ID_PRTY, vs, ve, _variant_seqn ,y.INSTNC_ST_NM ,y.SRC_SYS_NM ,y.ETL_PROC_NM ,y.ETL_BTCH_ID ,y.UPDT_DTS )
"""

def replacement(matched):
    columns = matched.group(3)
    columns = re.sub(dict_re["COLUMNS"], "", columns)
    return f"{matched.group(1)} ({columns})"



def insert_fix(sql):
    new_sql = re.sub(dict_re["INSERT"], lambda match: replacement(match), sql)
    return new_sql

# insert_fix(string)