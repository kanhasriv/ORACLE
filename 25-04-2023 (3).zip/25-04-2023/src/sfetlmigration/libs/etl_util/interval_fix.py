
# character/numeric to interval cast fix

# possible interval types : (year|month|day|hour|minute|second) [to (year|month|day|hour|minute|second)]
import re

placeholder_cnt = 1
placeholder = "+++PLACEHOLDER{}+++"
placeholderDict = {}

and_cnt = 1
aandList = []

second_metric_lst = ["s","ms","us","ns"]
time_metric_dict = {"hour":0, "minute":1, "second":2, "0":"h", "1":"m", "2":"s"}

abbrMap = {
    "year":"y",\
    "month":"mm",\
    "day":"d",\
    "hour":"h",\
    "minute":"m",\
    "second":"s"
}

durationDict = {
    "y":0,\
    "q":0,\
    "mm":0,\
    "w":0,\
    "d":0,\
    "h":0,\
    "m":0,\
    "s":0,\
    "ms":0,\
    "us":0,\
    "ns":0
}

# custom modf implementation based on string repr (slower than math.modf but w/o precision issues)
def modf(string):
    string = string.split(".")
    frac = 0.0
    sig = 0
    if len(string)> 1:
        frac,sig = float("."+string[1]),int(string[0])
    else:
        sig = int(string[0])
    return frac,sig

def parse_second(string):
    frac, sig = modf(string)
    curr_metric = 0
    place = 1000
    durationDict[second_metric_lst[0]] = sig
    while curr_metric != 3:
        curr_metric += 1
        frac *= place
        frac_part,sig_part = modf(str(frac))
        durationDict[second_metric_lst[curr_metric]] = int(sig_part%place)
        if float(frac_part) == 0:
            break

def to_string():
    # compile everything into a string
    res = ""
    for key in durationDict.keys():
        val = int(durationDict[key])
        if val != 0:
            res += str(val) + " " + key + ", "
    return "interval '" + res.rstrip(", ") + "'"

def parse_time(string, dt_type):
    time_parts = string.split(":")
    index = 0
    start = time_metric_dict[dt_type[0].strip()]
    end = time_metric_dict[dt_type[1].strip()]
    while start <= end :
        if start != 2:
            durationDict[time_metric_dict[str(start)]] = time_parts[index]
        else :
            parse_second(time_parts[index])
        index += 1
        start += 1

def parse_w_range(val, dt_type):
    words = [i for i in dt_type.split("to") if len(i.strip()) > 0]
    if words[0].strip().find("day") >= 0:
        val = val.split(" ")
        durationDict["d"] = val[0]
        val = val[1]
        words[0] = "hour"
    elif words[0].strip().find("year") >= 0:
        val = val.split(" ")
        durationDict["y"] = val[0]
        # with year we only have scenario of "year to month"
        durationDict["mm"] = val[1]
        return
    parse_time(val, words)

def parse_wo_range(val, dt_type):
    global durationDict
    global abbrMap
    if dt_type != 'second':
        durationDict[abbrMap[dt_type]] = int(val)
    else :
        parse_second(val)

# assumption : interval clause extracted from block
# input = trimmed string (interval clause) without extra spaces
def parse_clause_1(string):
    string = string.lower()
    match = re.search(r"['\"]([^']*)['\"]", string)
    if match is None:
        return "EMPTY"
    val = match.group(1)
    words = string[match.end():].strip()
    # removing precision
    words = re.sub(r"\([^\(\)]*\)" ,"",words)
    is_range = False
    if words.find("to") >= 0:
        is_range = True
    if not is_range:
        parse_wo_range(val, words)
    else:
        parse_w_range(val, words)
    return to_string()
    
def parse_clause_2(string, match):
    generated_string = "interval '" + match.group(2) + "' " + match.group(3)
    generated_string = decode(generated_string)
    return parse_clause_1(generated_string)
    
def find_cast(string, end):
    while end >= 4:
        if string[end-4:end] == "cast":
            return (end-4)
        end-=1
    return -1

def and_add(string):
    for match in re.finditer(r"\((\d)\)",string):
        aandList.append(match.group(1))
    return re.sub(r"\((\d)\)","&&&",string)
    
def remove_add(string):
    match = re.search(r"&&&", string)
    index = 0
    while match is not None :
        start = match.start()
        end = match.end()
        val = aandList[index]
        string = string[:start] + "("+val+")" + string[end:]
        index += 1
        match = re.search(r"&&&", string)
    return string
    
def parse2(string):
    string = and_add(string)
    start = 0
    res = ""
    # prev regex
    #for match in re.finditer(r"(?i)(interval.*?\'.*?\'\s*.*?(((hour|day|minute).*?(second|hour|minute|day)|"
    #+"(hour|day|minute)?\&\&\&)|((hour|day|minute).*?(second|hour|minute|day)|(hour|day|minute))))", string):
    for match in re.finditer(r"(?i)interval\s*?\'.*?\'\s*((year)|(day)|(hour)|(minute))(&&&)*(\s*(to)\s*((month)|(hour)|(minute)|(second))(&&&)*)*" ,string):
        new_val = parse_clause_1(remove_add(match.group(0)))
        res += string[start:match.start()] + new_val
        start = match.end()
    res += string[start:]
    res = remove_add(res)
    return res
    
    
def parse(string):
    global placeholder_cnt, placeholder, placeholderDict
    match = re.search(r"\(([^\)\(]*)\)", string)
    while match is not None :
        start = match.start()
        end = match.end()
        val = string[start:end]
        type2match = re.search(r"\((['\"]([^']*)['\"][\s]+as[\s]+interval[\s]+([^\)]*))\)", val)
        if type2match is not None :
            # found type 2
            # find a replacement
            val = parse_clause_2(val.strip("()"), type2match)
            # find recent 'cast' and delete it modifying the start index
            start = find_cast(string, start)
        string = (string[:start] if start > 0 else "") + placeholder.format(str(placeholder_cnt)) + string[end:]
        placeholderDict[placeholder.format(str(placeholder_cnt))] = val
        placeholder_cnt += 1
        match = re.search(r"\(([^\)\(]*)\)", string)

    return decode(string)
 
def decode(txt):
    match = re.search(r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+", txt)
    while match is not None :
        start = match.start()
        end = match.end()
        val = txt[start:end]
        txt = txt[:start] + placeholderDict[val] + txt[end:]
        match = re.search(r"(?i)\+\+\+PLACEHOLDER(\d)+\+\+\+", txt)
    return txt    
    
    
stringgg1 = "interval '24:00:00'  hour to second"
# regex = \((['\"]([^']*)['\"][\s]+as[\s]+interval[\s]+([^\)]*))\)
stringgg = "sd sdgb  sd cast('2 413:23:0.2323' as interval day(4) to second ) as something bla bla bla\n interval '32 2323:323:0.3232' day(3) to second"


def interval_fix(string):
    global aandList
    aandList = []
    return parse2(parse(string))