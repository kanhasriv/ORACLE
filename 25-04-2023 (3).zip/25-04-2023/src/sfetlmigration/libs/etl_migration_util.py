"""
Contains supporting functions for etl migration
"""

import os
import sys
import uuid
import logging
import datetime
import traceback
import concurrent.futures
from ftplib import FTP
from multiprocessing import cpu_count
from flask import jsonify
from config import config, db, send_message
from libs.etl_util.Tera_python_with_updfix import main

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
input_file_check = 'files_list.input_file'
snowflake_file_check = "files_list.$.snowflake_file"
snowflake_pyexec_check = "files_list.$.snowflake_python_exec"


def parallel_etl_td_sf(file_name, file, job_id, job_run_id, link_service_id, path, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    parallel etl_td_sf
    """
    item_id = str(uuid.uuid4())
    try:
        # Main function call
        start_time = int(datetime.datetime.utcnow().timestamp())
        start_time_str = datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format)
        db.job_run.update_one({"job_run_id": job_run_id}, {'$push': {
            'files_list': {"input_file": file_name + ".btq"}}})
        db.job_run_detail.insert_one({"item_id": item_id, "job_id": job_id,
                                      "job_run_id": job_run_id,
                                      "input_file": file_name + ".btq", "status": "InProgress",
                                      "start_time": start_time, "start_time_str": start_time_str})
        main(file_name, '\n'.join(file), link_service_id, job_id, job_run_id, path)

        if socket_flag:
            send_message("sf_etl_run_status", {file_name:{"status":"Success"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)

        # Update IDEA metadata
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_run_id": job_run_id,
                               input_file_check: file_name + ".btq"},
                              {"$set": {snowflake_file_check: "SF_" + file_name + ".sql",
                                        snowflake_pyexec_check: "SF_" +
                                        file_name + ".py"}})
        db.job_run_detail.update_one({"item_id": item_id}, {"$set": {"status": "Success",
                                                                     "end_time": end_time,
                                                                     "snowflake_file": "SF_" +
                                                                    file_name + ".sql",
                                                                     "snowflake_python_exec":
                                                                         "SF_" + file_name + ".py",
                                                                     "end_time_str": end_time_str,
                                                                     "message":"Script converted successfully"}})
    except Exception:
        if socket_flag:
            send_message("sf_etl_run_status", {file_name:{"status":"Fail"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_run_id": job_run_id,
                               input_file_check: file_name + ".btq"},
                              {"$set": {snowflake_file_check: "",
                                        snowflake_pyexec_check: ""}})
        db.job_run_detail.update_one({"item_id": item_id}, {"$set": {"status": "Fail",
                                                                     "end_time": end_time,
                                                                     "snowflake_file": "",
                                                                     "snowflake_python_exec": "",
                                                                     "end_time_str": end_time_str,
                                                                     "message":"Error while converting script statements"}})
        log.error(traceback.format_exc())
        etl_td_sf.fail_flag = 1


def handle_binary(more_data):
    """
    handle binary
    """
    data.append(more_data)
    return data


def get_error_info():
    """
    get error info
    """
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    error_string = "FileName : " + fname + ", LineNumber : " +\
                   str(exc_tb.tb_lineno) + ", ExceptionType : " + str(
        exc_type) + ", Exception : " + str(exc_obj)
    return error_string


def connect_ftp(host, user, pwd, path, file_list, job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    connect ftp
    """
    files = []
    file_names = []
    global data
    try:
        # Connecting FTP server
        global ftp
        ftp = FTP()
        ftp.connect(host,port)
        ftp.login(user,pwd)
        ftp.cwd(path)
        # ftp.set_pasv(False)

        # File validation
        files_list = ftp.nlst()
        for file_name in file_list:
            if file_name in files_list:
                ftp.retrlines("RETR " + path + file_name, callback=handle_binary)
                files.append(data)
                file_names.append(file_name.split(".")[0])
                data = []
            else:
                if socket_flag:
                    send_message("sf_etl_run_status", {file_name.split(".")[0]:{"status":"Fail"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                file_name = file_name.split(".")[0]
                log.error(traceback.format_exc())
                start_time = int(datetime.datetime.utcnow().timestamp())
                start_time_str = datetime.datetime.fromtimestamp(
                    start_time).strftime(idea_date_format)
                end_time = int(datetime.datetime.utcnow().timestamp())
                end_time_str = datetime.datetime.fromtimestamp(
                    end_time).strftime(idea_date_format)
                db.job_run.update_one({"job_run_id": job_run_id},
                                      {'$push': {'files_list': {"input_file": file_name + ".btq"}}})
                db.job_run.update_one({"job_run_id": job_run_id,
                                       input_file_check: file_name + ".btq"},
                                      {"$set": {snowflake_file_check: "",
                                                snowflake_pyexec_check: ""}})
                
                # Updating IDEA metadata if file not present in FTP server
                db.job_run_detail.insert_one({"item_id": str(uuid.uuid4()),
                                              "job_id": job_id, "job_run_id": job_run_id,
                                              "input_file": file_name + ".btq", "status": "Fail",
                                              "start_time": start_time,
                                              "start_time_str": start_time_str,
                                              "snowflake_file": "",
                                              "snowflake_python_exec": "", "end_time": end_time,
                                              "end_time_str": end_time_str,
                                              "message":"File does not exist at provided path"})
                log.error(traceback.format_exc())
                etl_td_sf.fail_flag = 1
        ftp.quit()
    except Exception:
        start_time = int(datetime.datetime.utcnow().timestamp())
        for file_name in file_list:
            if socket_flag:
                send_message("sf_etl_run_status", {file_name.split(".")[0]:{"status":"Fail"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            db.job_run_detail.insert_one({"item_id": str(uuid.uuid4()),
                "job_id": job_id, "job_run_id": job_run_id,
                "input_file": file_name, "status": "Fail",
                "start_time" : start_time,
                "start_time_str": datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format),
                "snowflake_file": "",
                "snowflake_python_exec": "", "end_time": start_time,
                "end_time_str": datetime.datetime.fromtimestamp(start_time).strftime(idea_date_format),
                "message": "Error connecting FTP server"})
        log.info(get_error_info())
        return jsonify({"message": "Error connecting FTP server"})
    return files, file_names


def etl_td_sf(host, user, pwd, path, job_id, job_run_id, link_service_id, file_list,port, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    etl_td_sf
    """
    etl_td_sf.fail_flag = 0
    try:
        files, file_names = connect_ftp(host, user, pwd, path, file_list, job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=cpu_count()) as executor:
                for i, v in enumerate(files):
                    try:
                        executor.submit(parallel_etl_td_sf,
                                        file_names[i], v, job_id,
                                        job_run_id, link_service_id,path,
                                        user_id, socket_flag, pipeline_id, pipeline_run_id)
                    except Exception as e_error:
                        log.error(e_error)
                        log.error(traceback.format_exc())
                        etl_td_sf.fail_flag = 1
                        continue
        except Exception as e_error:
            log.error(e_error)
            log.error(traceback.format_exc())
            etl_td_sf.fail_flag = 1
            return False
        return etl_td_sf.fail_flag == 0
    except Exception:
        return False


data = []
