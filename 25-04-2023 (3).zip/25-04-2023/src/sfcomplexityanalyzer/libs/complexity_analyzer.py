"""
File contains consumer definition for complexity analyzer
"""

import datetime
import logging
from config import config, db, send_message
from libs.complexity_analyzer_util import process_complexity_analyzer
from libs.util import abcr_job_run

# Log reference
log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
abcr_error_log = "Error while producing message on job run topic"

def complexity_analyzer(data):
    """
    Complexity Analyzer for bteq scripts
    """

    log.info("START")
    try:

        # Fetching data parameters
        db_hostname = data["db_hostname"]
        db_user = data["db_user"]
        db_password = data["db_password"]
        file_path = data["file_path"]
        files = data['files']
        job_id = data['job_id']
        job_run_id = data['job_run_id']
        creation_time = data["creation_time"]
        job_name = data["job_name"]
        run_by = data["run_by"]
        port = data["port"]
        user_id = data["user_id"]
        socket_flag = data["socket_flag"]
        pipeline_id = data["pipeline_id"]
        pipeline_run_id = data["pipeline_run_id"]

        # Utility function call
        if process_complexity_analyzer(db_hostname,
                                       db_user, db_password, file_path,
                                       files, job_id, job_run_id,port, user_id, socket_flag, pipeline_id, pipeline_run_id):
            if socket_flag:
                send_message("sf_complexity_run_job_status", {"job_id": job_id, "status": "Success", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            end_time = int(datetime.datetime.utcnow().timestamp())
            end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
            query = {"job_run_id": job_run_id}
            run_status = db.job_run_detail.find(query, {"object_name":1,"object_type":1,"status": 1, "_id": 0})
            if config["ABCR"]["flag"] == "Y" and abcr_job_run("", end_time, "", job_id,
                                job_run_id, job_name, "MigrationSF-Complexity_Analyzer",
                                run_status, run_by, creation_time, "Success",
                                config['ABCR']['complexity'], "") == "Fail":
                    log.info(abcr_error_log)
                    db.job_run.update_one({"job_id": job_id,
                                           "job_run_id": job_run_id},
                                          {"$set": {"status": "Fail",
                                                    "end_time": end_time,
                                                    "end_time_str": end_time_str}})
            db.job_run.update_one({"job_id": job_id,
                                   "job_run_id": job_run_id},
                                  {"$set": {"status": "Success",
                                            "end_time": end_time, "end_time_str": end_time_str}})
            log.info("Complexity Analyzer Successful")
        else:
            if socket_flag:
                send_message("sf_complexity_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
            end_time = int(datetime.datetime.utcnow().timestamp())
            end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run.update_one({"job_id": job_id,
                                   "job_run_id": job_run_id},
                                  {"$set": {"status": "Fail",
                                            "end_time": end_time,
                                            "end_time_str": end_time_str}})
            if config["ABCR"]["flag"] == "Y" and abcr_job_run("", end_time, "", job_id,
                                job_run_id, job_name, "MigrationSF-Complexity_Analyzer",
                                "", run_by, creation_time, "Fail",
                                config['ABCR']['complexity'], "") == "Fail":
                    log.info(abcr_error_log)
            log.info("Complexity Analyzer Failed")
    except Exception as e_error:
        if socket_flag:
            send_message("sf_complexity_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        log.error(e_error)
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_id": job_id,
                               "job_run_id": job_run_id},
                              {"$set": {"status": "Fail",
                                        "end_time": end_time,
                                        "end_time_str": end_time_str}})
        if config["ABCR"]["flag"] == "Y" and abcr_job_run("", end_time, "", job_id,
                            job_run_id, job_name, "MigrationSF-Complexity_Analyzer",
                            "", run_by, creation_time, "Fail", config['ABCR']['complexity'], "") == "Fail":
                log.info(abcr_error_log)
        log.info("Something went wrong. Please try later")

    log.info("END")
