import os 
import configparser
import pymongo
import boto3

config=configparser.ConfigParser()

if "FLASK_ENV" in os.environ and os.environ["FLASK_ENV"]=="development":
    config.read("config.ini")
else:
    config.read("config.ini")

kv_client= ""
session=boto3.session.Session()

db_client = pymongo.MongoClient("mongodb://ideatfdocdb:ideatfdocdb%21%23@localhost:27017/?authSource=admin&readPreference=primary&directConnection=true&ssl=true&tlsAllowInvalidCertificates=true&tlsAllowInvalidHostnames=true&retryWrites=false")

db=db_client["idea_redshift_demo"]
