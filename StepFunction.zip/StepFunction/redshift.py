query = {
    "check_schema_query": "select table_name, column_name, data_type from "
                          "information_schema.columns where table_schema = '{schema_name}' and "
                          "table_name = '{table_name}'",
    "pre_copy_script" : "TRUNCATE {schema_name}.{table_name}"
}
